# 《CodeSage项目》——上下文经济学：记忆、预算与路由

## 6.1 三区记忆模型

`memory/working.py` 的模块 docstring 把三区模型画得很清楚：

```text
三区模型：
    ┌────────────────────────────────────────────┐
    │ 冻结区 frozen：系统提示 + 任务简报            │  永不压缩
    │ （跨轮次完全不变 → 可命中 prompt 缓存）        │
    ├────────────────────────────────────────────┤
    │ 压缩区 summary：中间轮次的结构化摘要           │  由 LLM 压缩产生
    │ （保留：已提交发现 / 审查进度 / 未决疑点）      │
    ├────────────────────────────────────────────┤
    │ 活跃区 active：最近 K 轮原文                  │  保持原样
    │ （保证推理连续性）                            │
    └────────────────────────────────────────────┘
```

对应到 `WorkingMemory` 的字段：

```python
@dataclass
class WorkingMemory:
    """三区工作记忆。"""

    active_window_turns: int = 4
    _frozen: list[dict[str, Any]] = field(default_factory=list, repr=False)
    _active: list[dict[str, Any]] = field(default_factory=list, repr=False)
    _summary: str = ""
    _events: list[CompressEvent] = field(default_factory=list, repr=False)
```

三个区各自回答一个问题：

- **冻结区**（`_frozen`）——「什么永远不变？」系统提示 + 任务简报，进循环时 `freeze()` 一次，此后永不改动。永不改动才有 prompt 缓存的命中机会（缓存按前缀匹配，前缀稳定是命中的前提）；
- **活跃区**（`_active`）——「什么必须保真？」最近 K 轮（默认 4 轮）的完整原文。模型对最近发生的事情保持「精确记忆」，保证推理连续性；
- **压缩区**（`_summary`）——「什么可以损失细节但必须保住信息？」更早的轮次被 LLM 压缩成结构化摘要。注意是**一个字符串**而不是消息列表——压缩产物是一段文本，以 `role=system` 的消息注入。

组装顺序在 `build()` 里是固定的：冻结区 → 摘要 → 活跃区。

```python
    def build(self) -> list[dict[str, Any]]:
        """组装完整消息序列：冻结区 + 摘要 + 活跃区。"""
        out: list[dict[str, Any]] = list(self._frozen)
        if self._summary:
            out.append(
                {
                    "role": "system",
                    "content": (
                        "## 历史审查过程摘要（此前轮次已压缩，发现均已记录）\n"
                        f"{self._summary}"
                    ),
                }
            )
        out.extend(self._active)
        return out
```

摘要消息的模板文本值得注意：「此前轮次已压缩，**发现均已记录**」——这句话是写给模型的心理暗示：不要因为看不到早期原文就慌，需要的信息都在摘要和你的提交记录里。压缩摘要是 `role=system` 而不是 `role=user`——把它放在「系统告诉你的事实」而不是「用户说的话」的位置上。

**触发与执行的分离。** 三区模型有一个值得单独指出的架构决定：`WorkingMemory` 自己**不决定**什么时候压缩——它只提供 `compress()` 执行动作；触发时机全部在 `AgentLoop` 里（第 06 篇的 6.2 展开）。这正是 4.4 讲的「循环不认识压缩细节」的另一半：**记忆不认识循环节奏**。两边通过「loop 在合适的时机调 `memory.compress(compressor)`」这一个接口耦合。

## 6.2 压缩：什么时候压、压什么、怎么保障不丢信息

**什么时候压。** 回顾第 04 篇的循环，压缩在 loop 里只有两个触发点：

| 触发点 | 条件 | 时机 | 为什么不打断推理 |
|---|---|---|---|
| 调用前强制压缩 | HARD（≥80%） | LLM 调用之前 | 不压就放不下这一轮 |
| 回合边界压缩 | SOFT（≥60%）或 HARD | 一轮工具执行完之后 | 当前推理已结束 |

**压什么。** `compress()` 的输入是活跃区，输出是「把活跃区中除最近 K 轮外的部分交给压缩器」。第一步是找到切割点：

```python
    def _find_keep_index(self) -> int:
        """找到活跃区应保留的起始下标（保留最近 K 轮完整）。

        轮边界定义：assistant 消息开始一轮，其后跟着该轮的 tool 结果。
        cut 点必须落在某个 assistant 处——保证不切断 assistant-tool 配对
        （配对断了会造成 OpenAI 协议错误：tool 消息找不到对应的 tool_call）。
        返回 0 表示当前轮数不足、无需压缩。
        """
        assistant_indices = [
            idx
            for idx, msg in enumerate(self._active)
            if msg.get("role") == "assistant"
        ]
        if len(assistant_indices) <= self.active_window_turns:
            return 0
        return assistant_indices[-self.active_window_turns]
```

这段的逻辑很短，但每个约束都有来由。**「cut 点必须落在某个 assistant 消息上」**是全函数最重要的约束——因为 function calling 协议要求 `role=tool` 的消息必须能对应到前面某条 assistant 消息里的 `tool_call_id`。如果切割点落在「assistant（带 tool_calls）之后、它的 tool 结果之前」，被切走的 tool 消息就成了孤儿，下一次 API 调用直接协议报错。

所以切割逻辑不是「从倒数第 N 条消息切」，而是「找到倒数第 K 个 assistant 消息的下标，从它开始保留」——**assistant-tool 配对作为整体被保留或整体被压缩**。这类协议层的坑，test_memory.py 里有专门的用例覆盖。

**被压的部分怎么变成摘要。** 中间区的消息先被序列化——这一步有防「二次膨胀」的截断（单条 assistant 内容 600 字符、tool 结果 900 字符）：

```python
            if role == "assistant":
                tool_calls = msg.get("tool_calls") or []
                names = [
                    (tc.get("function") or {}).get("name", "?")
                    for tc in tool_calls
                    if isinstance(tc, dict)
                ]
                head = f"[assistant] 调用工具：{', '.join(names)}" if names else "[assistant]"
                parts.append(f"{head}\n{str(content)[:600]}")
            elif role == "tool":
                parts.append(f"[tool 结果] {str(content)[:900]}")
```

然后套上压缩 prompt：

```text
你是代码审查过程的信息压缩器。把下面的审查过程压缩为结构化摘要。

压缩要求（严格执行）：
1. 必须完整保留：所有已提交的发现（编号 + 文件:行号 + 一句话结论）、
   已审查的文件清单、未决疑点与待办。
2. 丢弃：重复的文件内容、冗长的工具原始输出、已完成的分析细节。
3. 输出为简洁的要点列表（纯文本），不要任何寒暄或说明。
4. 严禁遗漏“已提交的发现”——它们是最终报告的核心数据。

{previous}## 审查过程原文

{payload}
```

四条要求对应四个设计决策：

1. **保留清单是白名单式的**——「已提交发现 / 已审查文件 / 未决疑点」三类信息必须完整保留，其余皆可丢。这呼应规划文档里「结构化压缩而非自然语言摘要」的原则：压缩产物是**清单**（能检索、无歧义），不是「我们讨论过……」的叙述；
2. 明确告诉模型什么可以丢（重复内容、冗长输出）——给「丢弃」也立规矩，防止模型为省事丢错东西；
3. 禁寒暄——压缩产物直接进上下文，不能有「好的，以下是摘要」这种噪音；
4. 「严禁遗漏」单独强调，并且用了**第二次压缩的合并语义**：`{previous}` 槽在有旧摘要时填入「## 已有摘要（与本次新内容合并，不可丢失其中信息）」——**压缩是滚雪球式的**：新摘要必须包含旧摘要的信息。`test_memory.py` 里有一条测试专门验证「旧摘要参与了二次压缩」。

**失败保护：宁可占 token，不可丢信息。**

压缩的执行有两层保护。第一层在 `compress()` 里：压缩器抛异常或返回空串，都直接返回 None、不做任何状态改动：

```python
        try:
            new_summary = compressor(prompt)
        except Exception:  # noqa: BLE001 - 压缩失败保持原状（信息优先于成本）
            return None

        if not new_summary or not new_summary.strip():
            return None
```

第二层在 loop 的空操作分支（`_compress()` 发现没有注入 compressor 就直接 return）。两层保护对应 `test_memory.py` 的两条测试：压缩器返回空 → `mem.active_count == 6`（状态原样保留）；压缩器抛异常 → 同样原样。测试注释写明了原则：**「信息优先于成本」**——压缩失败最坏的结果是多占点 token，绝不能出现「摘要生成失败但原文已经丢了」。

**压缩本身也是一次 LLM 调用。** 压缩器实现在 `pipeline.py` 组装，用的是快模型 + 零温度：

```python
    def compressor(prompt: str) -> str:
        response = client.chat(
            [{"role": "user", "content": prompt}],
            model=router.model_for(TaskKind.COMPRESS),
            temperature=0.0,
        )
        budget.record(response.usage)
        return response.content
```

注意 `budget.record(response.usage)`——**压缩消耗的 token 也计入同一次审查的预算统计**。成本和执行都在同一本账上，评测里看到的「总 token」包含压缩开销，不会漏算。

每次压缩会产出一条 `CompressEvent`（移除几条消息、保留几条、摘要多少字符），计数体现在 `AgentResult.compress_events` 里，最终进报告。终端报告的概览区里会显示「压缩 N 次」——压缩机制在不在工作，一眼可见。

## 6.3 双阈值与熔断：四个状态，三道闸

`llm/budget.py` 的 docstring 先交代设计意图：

```python
"""Token 预算与熔断。

三层阈值（与三区记忆模型配套）：
    ratio < soft   → 正常执行
    ratio ≥ soft   → SOFT：回合边界触发压缩（不打断当前推理）
    ratio ≥ hard   → HARD：调用前强制压缩（阻塞，保证下一轮能放下）
    ratio ≥ abort  → ABORT：熔断，结束循环并输出已有发现（止损）

为什么需要熔断：宁可输出“不完整但不报错”的结果，也不让 API 调用
因超限失败导致整个审查白跑。
"""
```

状态判定就是一个从高到低的水位检查：

```python
    def state(self, current_context_tokens: int) -> BudgetState:
        ratio = self.ratio(current_context_tokens)
        if ratio >= self._settings.abort_ratio:
            return BudgetState.ABORT
        if ratio >= self._settings.hard_ratio:
            return BudgetState.HARD
        if ratio >= self._settings.soft_ratio:
            return BudgetState.SOFT
        return BudgetState.OK
```

默认参数换算成具体数字（上下文窗口 64000）：

| 状态 | 阈值 | 触发点（tokens） | 行为 |
|---|---|---|---|
| OK | < 60% | < 38400 | 正常执行 |
| SOFT | ≥ 60% | 38400 | 回合边界压缩（不打断推理） |
| HARD | ≥ 80% | 51200 | 调用前强制压缩（阻塞） |
| ABORT | ≥ 95% | 60800 | 熔断：结束循环，输出已有发现 |

三个阈值之间还留着安全余量：SOFT 触发压缩时，距离硬上限还有 20% 的空间——**压缩需要时间（一次 LLM 调用）和空间（压缩 prompt 自身的体积）**，在 60% 就开始处理，等于给自己留了充足的操作空间。这也是为什么 6.4 的估算器 ±20% 的误差可以接受——阈值本身留的安全垫就是这个量级。

**熔断的价值在「保底」。** 如果没有 ABORT 这一档，会发生什么：上下文逼近窗口上限 → 某次 API 调用被服务端拒绝（超限错误）→ `LLMError` → 循环以 `error` 状态退出。结果是**前面的发现能保住，但最后几轮的成果全丢，而且用户看到的是一个错误而不是报告**。有了熔断，最后一轮检查发现使用率 ≥95%，主动退出并把已有发现全部带走：

```python
            if budget_state == BudgetState.ABORT:
                result.status = "aborted"
                result.stop_reason = (
                    f"Token 预算熔断（使用率 ≥ {int(self._budget_ratio_abort * 100)}%），"
                    "输出已有发现"
                )
                break
```

「不完整但可用」优于「完整但崩溃」——这是所有长流程 Agent 的通用生存法则，CodeSage 把它落成了一个显式的预算状态。

`TokenBudget` 还顺手承担了成本统计：`record()` 累积每次真实调用的 `TokenUsage`（以 API 返回为准），`cost_yuan()` 按配置单价（默认输入 2 元 / 输出 8 元每百万 token，DeepSeek 参考价）估算累计成本。报告里的「¥0.0X」就是从这里来的。

## 6.4 Token 估算器：为什么要自己写一个

预算系统的基础设施是「估算当前上下文有多少 token」。行业标准答案是 tiktoken，但项目选择了启发式估算作默认，`llm/tokenizer.py` 的 docstring 解释了权衡：

```python
"""Token 估算器：预算控制的基础设施。

设计取舍（为什么默认不用 tiktoken）：
- tiktoken 首次运行需要联网下载 BPE 编码文件，国内环境容易卡住；
- 预算控制只需要 ±20% 量级的精度（熔断阈值留有安全余量），
  启发式估算完全够用；
- 抽象出 TokenEstimator 接口，需要高精度时一行切换（prefer_tiktoken=True）。
"""
```

启发式估算的规则简单到可以背下来——**CJK 字符 1 字符 ≈ 1 token，其余字符 3.5 字符 ≈ 1 token**：

```python
    def estimate(self, text: str) -> int:
        if not text:
            return 0
        cjk = 0
        for ch in text:
            if self.CJK_RANGE[0] <= ch <= self.CJK_RANGE[1]:
                cjk += 1
        other = len(text) - cjk
        return int(cjk + other / 3.5) + 1
```

这个经验公式对 GPT / DeepSeek 系的 BPE 分词适用：英文和代码约 3.5 字符一个 token，中文汉字基本一字一 token。对「何时触发压缩」这个决策来说，±20% 的精度足够——因为阈值之间（60%/80%/95%）本来就有巨大的安全间距。

`estimate_messages()` 在文本之上补了消息结构的开销：

```python
    def estimate_messages(self, messages: list[dict[str, Any]]) -> int:
        """估算完整消息列表（含角色开销与 tool_calls 的 JSON 体积）。

        每条消息额外 +4 token（OpenAI 消息包装开销的经验值），
        整个请求再 +3。
        """
```

另外它还专门处理了 `tool_calls` 字段的 JSON 体积（序列化后估算，失败兜底 +50）——**带工具调用的 assistant 消息通常比纯文本消息大得多**，不估这块会显著低估。

`get_estimator()` 提供了平滑的升级路径：

```python
def get_estimator(prefer_tiktoken: bool = False) -> TokenEstimator:
    """获取估算器：默认启发式，可尝试升级为 tiktoken。"""
    if prefer_tiktoken:
        try:
            return TiktokenEstimator()
        except Exception:  # noqa: BLE001 - 任何失败都优雅回退
            pass
    return HeuristicEstimator()
```

就算显式要求 tiktoken，下载失败也会静默回退到启发式——**依赖的高可用性优先于精度**。这个模式（Protocol 接口 + 默认轻实现 + 可选重实现 + 静默回退）在项目里出现多次，值得当成一个通用工程套路记住。

## 6.5 模型路由：把贵的 token 用在推理上

`llm/router.py` 定义任务分级。先看枚举：

```python
class TaskKind(str, Enum):
    """LLM 调用任务类型。"""

    DECISION = "decision"  # ReAct 循环内的工具决策
    COMPRESS = "compress"  # 记忆压缩摘要
    REVIEW = "review"      # 深度审查 / 最终总结
    JUDGE = "judge"        # 评测打分（LLM-as-judge）
```

但 `model_for()` 的实际实现是这样的：

```python
    def model_for(self, kind: TaskKind) -> str:
        # 压缩摘要属于轻任务；工具决策与深度审查共享同一次推理调用
        # （模型在决策的同时就在分析代码），必须用强模型保证审查质量。
        if kind == TaskKind.COMPRESS:
            return self._settings.model_fast
        return self._settings.model_strong
```

这里有一个值得品味的**设计与实现的分歧**：模块 docstring 写的设想是「DECISION / COMPRESS → 快模型」，但实现只把 COMPRESS 路由到快模型。原因写在代码注释里——**在本项目的架构中，「工具决策」和「深度审查」是同一次 LLM 调用**。模型在读代码、决定调哪个工具的那次调用里，同时就在做分析；把这次调用降级到快模型，省了钱但直接伤害审查质量。所以路由的实际形态是：

| 任务 | 路由 | 理由 |
|---|---|---|
| 记忆压缩（COMPRESS） | 快模型，temperature=0.0 | 轻任务：把消息列表摘成要点 |
| 审查与决策（REVIEW，含工具决策） | 强模型 | 一次调用同时承担决策与分析 |
| DECISION | **枚举值已定义，当前没有单独使用** | 与 REVIEW 合并调用 |
| JUDGE | **枚举值已定义，当前没有使用** | 为「评测环节的 LLM-as-judge」预留；当前评测用确定性软匹配（第 07 篇） |

这就是导读写明的「诚实标注」的一个实例——`TaskKind` 里有两个枚举值目前没有实际路由场景。它们的存在有两种读法：一是设计预留（JUDGE 确实是 v2 的评测增强方向），二是实现演进留下的痕迹（DECISION 原本计划独立路由，实现时发现合并更优）。代码注释选择了把第二种如实写出来。

## 6.6 LLM 客户端：薄封装的三个约定

`llm/client.py` 是 openai SDK 的薄封装（OpenAI 兼容协议），只守三个约定。模块注释直接列了出来：

```python
"""LLM 客户端：openai SDK 的薄封装（OpenAI 兼容协议）。

设计要点：
- 只暴露 CodeSage 自己的 LLMResponse / ToolCall 数据结构，
  openai SDK 的类型不泄漏到 Agent 层（可测试、可替换）；
- 消息格式直接使用 OpenAI 的 dict 协议（role/content/tool_calls/tool_call_id），
  因为自研 ReAct 循环原样维护它，无需转换；
- 惰性初始化底层 client，未配置 API Key 时给出明确错误。
"""
```

**约定一：SDK 类型不外泄。** 对外只有三个自有结构——`ToolCall`（id / name / arguments / raw_arguments / parse_error）、`LLMResponse`（content / tool_calls / usage / model）、`TokenUsage`。循环、Mock、测试都只认这些类型，openai SDK 的对象形状变化被挡在模块内部一层。这正是「可测试」的底座：`MockLLMClient` 能替换真客户端，是因为循环依赖的接口只有 `chat()` 一个方法。

**约定二：参数解析失败静默消化。** 模型返回的 tool_calls 参数是 JSON 字符串，可能格式出错。这里不抛异常，把失败记录在 `ToolCall.parse_error` 里、参数留空：

```python
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    arguments = parsed
                else:
                    parse_error = f"参数不是 JSON 对象：{raw[:120]}"
            except json.JSONDecodeError as exc:
                parse_error = f"参数 JSON 解析失败：{exc}"
```

参数解析失败的后果是：工具执行时缺少必填参数 → 返回「ERROR: 参数不匹配……」 → 模型下一轮自纠。**又一处「错误是可回填的信息、不是异常」**——和 5.1 的工具层防线形成上下呼应。

**约定三：惰性初始化 + 明确错误。** 客户端构造时不建连接，直到第一次 `chat()` 才初始化底层 SDK；未配置 API Key 时给出带出路的错误：

```python
        if not self.configured:
            raise LLMNotConfiguredError(
                "未配置 LLM API Key。请复制 .env.example 为 .env 并填入密钥，"
                "或使用 `codesage review --no-llm` 运行纯确定性分析。"
            )
```

错误消息里直接给两条出路（配密钥 / 用零成本模式）——错误处理的最好形式是「告诉用户下一步做什么」。底层 `OpenAI(...)` 的构造参数里还有一行 `max_retries=2  # SDK 自带指数退避重试`——HTTP 重试这种「标准且无优化空间」的能力用现成的，与第 04 篇「不重复造轮子」的判断标准同源。

**MockLLMClient：一个类管测试。** Mock 客户端按预置的响应序列返回，并记录每次请求的完整消息快照：

```python
        self.calls.append([dict(m) for m in messages])
```

`calls` 让测试可以断言「第二轮请求里有没有带上 ERROR 消息」「压缩后请求的消息序列长什么样」。9.5 会看到，循环的九个测试场景全部由它驱动。它的类 docstring 里还写着一条「`codesage review --mock` 演示模式」的用途——**诚实标注：该 CLI 选项当前并不存在**（`eval --mock` 走的是 `use_llm=False` 的真实确定性链路，不是这个 Mock 类）；这条漂移记录在结语的诚实清单里。

## 6.7 小结

- **三区模型**：冻结区（永不压缩、可命中缓存）+ 压缩区（LLM 结构化摘要、滚雪球合并）+ 活跃区（最近 K=4 轮原文）；组装固定为「冻结 + 摘要 + 活跃」。
- **压缩的三重纪律**：cut 点对齐 assistant（保住协议配对）；保留清单白名单式（发现/进度/疑点必留）；失败宁可占 token 不可丢信息。
- **三道闸**：SOFT 60%（回合边界压）/ HARD 80%（调用前强压）/ ABORT 95%（熔断保底）——数字之间留出的余量，是为「压缩本身也要花时间和空间」准备的。
- **估算器**：启发式（CJK 1:1、其余 3.5:1 + 消息开销）默认，tiktoken 可插拔且失败静默回退。
- **路由**：只有压缩用快模型；DECISION 与 REVIEW 合并为同一次调用（实现注释如实说明）；JUDGE 为预留。
- **客户端**：SDK 类型不外泄、参数解析失败静默回填、惰性初始化 + 带出路的错误——薄封装，但每个约定都在为可测试性与容错服务。

到这里，Agent 的「内部世界」讲完了：它怎么想（循环）、怎么动手（工具）、怎么记忆（三区）、怎么花钱（预算与路由）。接下来两大部分转向外部世界：怎么证明它干活干得好（评测），怎么让它越干越好（自优化）。
