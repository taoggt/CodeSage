# 《CodeSage项目》——评测体系：把「效果不错」变成数字

## 7.1 Harness 在系统中的位置

一个 AI 项目说「效果不错」，是没有信息量的；说「在 5 个案例上检出率 100%、精确率 75%、单案例成本 ¥0」，才是可以讨论、可以回归、可以对比的工程事实。`harness/` 这个模块存在的意义就是把前者变成后者。

评测运行器的模块注释把三条关键设计列了出来：

```python
"""评测运行器：对数据集批量执行真实审查链路并落盘结果。

关键设计：
- 走真实链路（调用 pipeline.run_review），而不是直接调分析器——
  保证评测结果反映用户实际使用时的行为（harness 不 import agent 内部模块）；
- mock 模式（--no-llm）只跑确定性层：无 API Key 也能验证指标管线、
  为 CI 提供稳定的回归基线；
- 结果落盘 JSONL（逐案例）+ summary JSON（聚合指标），
  供 compare 做 A/B 回归。
"""
```

逐案例的执行流程：加载数据集 → 对每个案例开一个**隔离的临时工作区** → 在里面跑完整的 `run_review()` → 用软匹配评估结果。隔离那一步是评估可信度的关键：

```python
        with tempfile.TemporaryDirectory(prefix="codesage_eval_") as tmp:
            tmp_path = Path(tmp)
            # 隔离工作区：只放该案例的片段（保证报告的问题都针对目标代码）
            shutil.copy2(case.snippet_path, tmp_path / case.snippet_name)

            report = run_review_fn(
                tmp_path,
                self._settings,
                options_cls(
                    use_llm=not self._options.mock,
                    profile=self._options.profile,
                    quiet=True,
                ),
            )
```

为什么每个案例要开独立工作区？因为审查器会扫描目录、读取文件、还可能往 `.codesage/` 里落盘——如果所有案例在同一目录里跑，案例之间的文件会互相干扰（A 案例的发现可能来自 B 案例的文件）。**一个案例 = 一个干净的世界**，测量才成立。

`EvalOptions` 支持三个开关：`mock`（只跑确定性层——即 `use_llm=False`，不是假数据，是真实跑确定性分析）、`sample`（只跑前 N 个案例，开发期快速迭代）、`profile`（切换审查角色）。

个中还有一个小的可观测性设计——`on_progress` 回调。CLI 里长这样：

```python
    def on_progress(case_id: str, idx: int, total: int, result: dict) -> None:
        mark = "[green]检出[/green]" if result["detected"] else "[red]漏报[/red]"
        console.print(
            f"[dim][{idx}/{total}][/dim] {case_id}（{result['category']}）"
            f" → {mark}，报告 {result['reported']} 条"
        )
```

每跑完一个案例就打印「检出/漏报」——评测过程本身就是验收过程。

## 7.2 数据集：案例长什么样

数据集是 YAML 文件，一个案例一个文件。加载后的 `EvalCase` 结构：

| 字段 | 含义 |
|---|---|
| `id` | 案例编号 |
| `category` | 维度：security / bug / performance / quality |
| `description` | 案例描述 |
| `snippet_path` | 缺陷代码片段（绝对路径） |
| `line_start` / `line_end` | ground truth 的缺陷行区间 |
| `keywords` | 软匹配关键词 |
| `severity` | ground truth 严重级 |

拿 case_001 说话。YAML 文件全文：

```yaml
id: case_001
category: security
description: SQL 注入 - f-string 拼接用户输入进查询语句
snippet: snippets/case_001.py
ground_truth:
  line_range: [9, 10]
  severity: major
  keywords: ["sql", "execute", "注入"]
```

对应的代码片段：

```python
"""用户服务模块（评测案例：SQL 注入）。"""
import sqlite3


def get_user(username: str):
    """按用户名查询用户记录。"""
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    query = f"SELECT id, name FROM users WHERE name = '{username}'"
    cursor.execute(query)
    return cursor.fetchone()
```

注意 ground truth 的构成：**行区间 + 严重级 + 关键词**。它不要求「检出结果的文本和某个标准答案一致」——这是 7.3 软匹配的前提。

种子集目前 5 个案例，覆盖的维度：

| 案例 | 维度 | 缺陷 |
|---|---|---|
| case_001 | security | SQL 注入（f-string 拼接） |
| case_002 | bug | 资源泄漏（open 未 with）+ 可变默认参数 |
| case_003 | performance | 循环内 `+=` 拼接字符串（O(n²)） |
| case_004 | quality | 裸 except + `== None` + 公共函数缺 docstring |
| case_005 | security | 命令注入（`subprocess shell=True`） |

**诚实标注**：5 个种子案例是手工构造的，规模离「统计显著」还很远（best_practice 维度暂无案例）。数据集扩充的管道写在 `examples/eval_dataset/README.md` 里——从开源项目挖真实 bugfix commit：

```text
1. 选择 3-5 个活跃 Python 开源项目；
2. 筛选 commit message 含 fix / bug / security 的提交；
3. 取 parent 版本的相关文件片段 = buggy 代码（snippet）；
4. diff 与测试变更 → 推导 ground_truth 的 line_range 与 keywords；
5. 人工复核后放入本目录，目标 25-30 个案例（5 类 × 5-6 个）。
```

「从历史修复中挖真实 bug」是构建评测集的经典方法：bugfix commit 天然带着「修改前的错误代码」和「修改后的正确代码」+「ground truth 的隐含验证（修复 commit 本身）」。这份 README 把方法留了下来，等数据集扩充时照着执行。

## 7.3 软匹配：为什么不能精确比对

评测里最容易设计错的一环是「怎么判断一条发现命中了 ground truth」。

Ground truth 是「第 9-10 行有 SQL 注入」；系统的输出是自然语言发现（「execute 使用 f-string 拼接查询」）。让两者做精确文本比对是不可能的——同一个问题可以被描述成十种句式。`harness/metrics.py` 的模块注释把这个困难和方法都写清楚了：

```python
"""指标：软匹配 + 检出率 / 误报率 / F1 聚合。

为什么需要"软匹配"（核心工程细节）：
- ground truth 是"第 8-9 行有 SQL 注入"；
- 模型输出是自然语言发现（"execute 使用 f-string 拼接"）；
- 精确文本比对不可行，采用三重软匹配：
    1) 文件名匹配（basename）
    2) 行区间重叠 ≥ 30%
    3) ground truth 关键词至少命中 1 个
  三个条件同时满足才判定"检出"。
```

三个条件全部满足才算命中，实现就是一个三段判断：

```python
def match_finding(finding: Finding, case: EvalCase, min_overlap: float = 0.3) -> bool:
    """判断一条发现是否命中 ground truth。"""
    if not _file_match(finding.file, case):
        return False

    if overlap_ratio(
        (finding.line_start, finding.line_end),
        (case.line_start, case.line_end),
    ) < min_overlap:
        return False

    if case.keywords:
        haystack = " ".join(
            [finding.title, finding.description, finding.suggestion]
        ).lower()
        if not any(k.lower() in haystack for k in case.keywords):
            return False
    return True
```

其中区间重叠的比例定义为「交集长度 / 较短区间长度」：

```python
def overlap_ratio(a: tuple[int, int], b: tuple[int, int]) -> float:
    """区间重叠比例 = 交集长度 / 较短区间长度。"""
```

用「较短区间」做分母（而不是并集）是一个对检出有利的选择：规则报出的行区间常常比 ground truth 窄（比如只报 `execute` 那一行，而 ground truth 覆盖两行），用较短区间做分母能避免「报得准反而被罚」。

关键词用的是「三字段拼接 + 任一命中」——`title`、`description`、`suggestion` 里任何一个字段包含任一关键词即可。这也解释了 case_001 的关键词为什么是 `["sql", "execute", "注入"]` 这种宽泛的特征词：**关键词宁可宽，匹配器还有行区间这一道锁**，两道锁同时满足才算数。

**匹配器的局限 —— 模块注释选择主动坦白：**

> 匹配器的局限（诚实标注）：
> - 同一文件中的其他真实问题会被计入误报（工作区按案例隔离可缓解）；
> - 关键词需要人工选择（一般取问题特征词，如 "execute"、"shell"）。

第一条尤其值得理解：如果案例片段里除了注入的那一行，还恰好有另一个真实问题（比如 case_004 里同时有裸 except、`== None`、缺 docstring 三个问题），系统把它们也报出来——但 ground truth 只登记了「区间内至少一个问题」，多报的那些在精确率分母里就成了「未命中」。所以项目里的 precision **是近似指标**，README 也如实标注了这一点：

> \* 精确率为近似指标：案例工作区隔离后，同一片段中的其他真实问题也会计入分母（详见 `harness/metrics.py` 的诚实标注）。

第二条则说明关键词是人工维护的——这是软匹配的固有成本，接受它换来的是「模型措辞变化不再影响评测」。

顺带一提：这个匹配器本身也有测试（`tests/test_metrics.py`，模块注释「指标测试：软匹配器（行区间 + 关键词）与聚合」）——测试里手工构造 `EvalCase` 和 `Finding`，覆盖「文件名不符/区间不重叠/关键词不命中/全部满足」几类组合。**评价系统自己的正确性也要被测试**，否则「检出率」这个数字本身就不可信。

## 7.4 指标与 A/B：数字怎么算、怎么比

聚合逻辑只有几十行，定义全部写在注释里：

```python
def aggregate(results: list[dict]) -> dict:
    """聚合指标。

    - recall（检出率）= 检出案例数 / 总案例数
    - precision 近似 = 全部命中发现数 / 全部报告发现数
      （每案例工作区隔离，报告的问题都针对目标片段；
        未命中 ground truth 的报告计入误报侧的近似——见模块 docstring）
    - f1 = 2PR / (P + R)
    """
```

| 指标 | 口径 | 说明 |
|---|---|---|
| Recall（检出率） | 检出的案例数 / 总案例数 | 案例级：这个案例的缺陷被抓到了吗 |
| Precision（精确率） | 全部命中发现数 / 全部报告发现数 | 发现级：报出来的里有多少是命中 |
| F1 | 2PR / (P + R) | 两者调和平均 |
| Token 总量 / 成本 | 汇总每个案例的 `report.usage` | 单位：token / 元 |
| 耗时 | 各案例 wall-clock 汇总 | 体验指标 |

注意 Recall 是**案例级**的（一个案例里有的 ground truth 被命中就算检出），这样做的好处是口径稳定、便于人工核对；代价是无法区分「部分命中」——对 5 个案例的种子集，这是合理的简化。

A/B 对比在 `harness/compare.py`。它不是简单地把两个数字并排放，而是**逐案例找出回归和改善**：

```python
    for case_id in sorted(set(cases_a) & set(cases_b)):
        ca, cb = cases_a[case_id], cases_b[case_id]
        if ca.get("detected") and not cb.get("detected"):
            regressions.append({"case_id": case_id, "detail": cb})
        elif not ca.get("detected") and cb.get("detected"):
            improvements.append({"case_id": case_id, "detail": cb})
```

模块注释列出了四个典型用途，并给了对比纪律：

> 对比原则（面试要点）：同一数据集、同一模型、同一参数——
> 只变一个自变量，否则对比结果无法归因。

「回归报告」的价值在 prompt 工程里特别明显：改了一版 prompt，总指标可能微涨，但某个案例从检出变成了漏报——只看总分会掩盖这种回归，逐案例对比能把它揪出来。终端里的呈现长这样（`eval_cmd.py` 的 `_render_compare`）：指标表（A 值 → B 值 → delta，涨绿跌红）+「回归案例（从检出变漏报）」清单 +「改善案例（从漏报变检出）」清单。

## 7.5 实测数据

项目里沉淀了多组真实的评测产物（`.codesage-eval/`），拿确定性层基线来说（`baseline-final`，mock 模式）：

| 配置 | 检出率 | 精确率* | F1 | 平均成本/案例 |
|---|---|---|---|---|
| 确定性层（mock） | **100%**（5/5） | 75% | **0.857** | ¥0 |
| 完整链路（LLM） | 待填（需 API Key 后运行 `codesage eval --tag v1-llm`） | | | |

- 12 条报告发现中 9 条命中（`reported_total: 12 / matched_total: 9`），5 个案例全部检出；整轮评测 11.6 秒。
- 另有一组靶场数据：对 `examples/demo_target`（6 个刻意植入缺陷的演示文件）跑 `--no-llm`，确定性分析产出 33 条候选、合并后 26 条进报告，耗时 1.41 秒——这个靶场本来就是拿来「跌分」的，评分低是设计预期。

**诚实标注**：完整 LLM 链路的评测数据还空着——需要在 `.env` 配置 API Key 后运行 `codesage eval --tag v1-llm` 取得。这是评测体系留给「第一次真实烧钱评测」的位置，也是 A/B 对比里的下一个变量（确定性层 vs 完整链路：模型多赚回来多少检出、多花多少钱）。

## 7.6 小结

- **三条设计纪律**：走真实链路（通过 `run_review` 而不是直接调分析器）、mock 可离线回归、结果落盘（JSONL + summary）可对比。
- **案例隔离**：每个案例在独立临时工作区里审查——测量可信度的前提。
- **软匹配三重条件**：文件名 + 行区间重叠 ≥30% + 关键词命中；precision 是近似指标，局限被主动标注。
- **A/B 的颗粒度**：逐案例识别「回归/改善」，而不是只比总分。
- **当前数据**：确定性层 100% 检出 / F1 0.857 / 零成本；LLM 全链路评测待配置 API Key。

评测回答了「它现在干得多好」。第 08 篇回答下一个问题：**怎么让它越干越好**。
