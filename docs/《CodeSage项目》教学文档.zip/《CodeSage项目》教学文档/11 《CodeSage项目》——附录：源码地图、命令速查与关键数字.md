# 《CodeSage项目》——附录：源码地图、命令速查与关键数字

## A. 源码地图（文件 → 对应篇目）

| 源码 | 职责 | 对应章节 |
|---|---|---|
| `pipeline.py` | 编排管线 `run_review()` | 1.3 / 5.3 |
| `core/models.py` | Finding / Severity / 评分 / 去重 | 1.4 |
| `core/config.py` | 三源配置加载 | 9.2 |
| `core/errors.py` | 异常体系（9 个异常类） | 9.3 |
| `ingest/scanner.py` + `filters.py` | 扫描与四道筛子 | 2.1 |
| `ingest/chunker.py` | 按函数边界切块 | 2.2 |
| `ingest/git_diff.py` | git diff 解析（增量模式） | 2.3 |
| `analyzers/ast_rules.py` | 13 条规则 + 引擎 | 3.1–3.3 |
| `analyzers/base.py` | Analyzer 协议 / find_tool / is_test_file | 3.4–3.5 |
| `analyzers/ruff/bandit/radon_runner.py` | 三个外部分析器 | 3.4 / 9.4 |
| `agent/loop.py` | ReAct 主循环 | 4 |
| `agent/registry.py` | 工具注册表 | 5.1 |
| `tools/*`（7 个） | 工具集 | 5.2–5.3 |
| `agent/policies.py` | 停止策略 | 5.4 |
| `agent/profiles.py` + `context.py` | 系统提示 / 任务简报 | 5.5 |
| `memory/working.py` | 三区记忆与压缩 | 6.1–6.2 |
| `memory/store.py` + `project.py` | SQLite 落盘 / 项目画像 | 8.2 / 5.5 |
| `llm/budget.py` | 预算与熔断 | 6.3 |
| `llm/tokenizer.py` | Token 估算器 | 6.4 |
| `llm/router.py` | 模型路由 | 6.5 |
| `llm/client.py` | LLM 客户端（含 Mock） | 6.6 |
| `optim/*` | 反馈 / 错题本 / Prompt 版本 | 8 |
| `harness/*` | 数据集 / 指标 / 运行器 / 对比 | 7 |
| `cli/*` | 命令 / 渲染 / 导出 | 9.1 |

## B. 命令速查

```bash
# 审查
codesage review ./src                      # 完整审查（需 API Key）
codesage review app.py --no-llm            # 零成本模式
codesage review . --changed                # 只审 git 变更文件
codesage review . --profile security       # 安全聚焦
codesage review . --format json -o r.json  # 导出 JSON
codesage review . --fail-on major          # CI：有 P0/P1 则退出码 1

# 评测
codesage eval --mock --tag det-baseline    # 确定性层基线（零成本）
codesage eval --tag v1-llm                 # 完整链路（需 API Key）
codesage eval --compare det-baseline,v1-llm  # A/B 对比
codesage eval --sample 3 --tag quick       # 小样本快跑

# 反馈与历史
codesage feedback <finding_id> -v wrong -n "理由"
codesage feedback --mine                   # 提炼错题本
codesage feedback --show                   # 查看错题本
codesage history                           # 历史审查记录
```

## C. 关键数字速查

| 维度 | 数字 |
|---|---|
| 源码规模 | 62 个 Python 文件，约 6253 行（`src/`，不含测试） |
| 测试 | 9 个测试文件 / 85 个用例 / 全量 2.54s |
| 自研规则 | 13 条（CG001–CG013）+ 语法错误 CG000 + LLM 发现标记 CG-LLM |
| 工具 | 7 个 |
| 知识卡片 | 6 张（pythonic / security / performance / patterns / exceptions / resources） |
| 评测种子案例 | 5 个（security×2 / bug / performance / quality） |
| 默认预算 | 上下文 64000 tokens；阈值 60% / 80% / 95% |
| 默认行为 | 轮次上限 12；活跃区 4 轮；候选注入上限 40；工具输出截断 6000 字符 |
| 性能 | 自举审查 92.7s → 2.1s（约 44 倍） |
| 实测评测 | 确定性层 Recall 100%（5/5）、Precision 75%、F1 0.857、¥0/案例 |

---

*本组文档基于 CodeSage v0.1.0 源码整理；所有代码引用与源码逐字一致，数字均来自项目内的运行产物与 README。*
