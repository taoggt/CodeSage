# 《CodeSage项目》——认知篇：一个 LLM 代码审查工具，怎么跳出「玩具」的层次

## 1.1 玩具项目的两个死穴

先说清楚反面教材长什么样。市面上的「LLM 代码审查」玩具项目基本都是同一个套路：

**读代码 → 塞进 Prompt → 打印模型输出。**

这个套路有两个绕不开的死穴。

**第一，成本失控。** 一次审查如果真把整个仓库塞进上下文，token 消耗随代码量线性膨胀，账单不可控；而实际上，一个仓库里 90% 的代码是没问题的，模型在它们身上花掉的每一个 token 都是浪费。

**第二，质量不可控。** 让模型「自由发挥」地审查，输出的格式、粒度、严重级判断全是随机的。更致命的是**误报**——开发者被误报骚扰三次之后就会弃用这个工具，宁可漏报也不可误报是审查工具的铁律。

## 1.2 CodeSage 的回答：三级任务分工

CodeSage 的核心判断是：**不同确定性的任务，应该用不同的通道处理。**

| 任务类型 | 例子 | 处理通道 | Token 成本 |
|---|---|---|---|
| 确定性任务 | 文件筛选、AST 模式匹配、调用 Ruff/Bandit | 纯工程代码 | 零 |
| 半确定性任务 | 可疑片段的语义确认、误报复核 | LLM 短上下文复核 | 少量 |
| 开放任务 | 逻辑错误推理、修复建议生成 | LLM 深度审查 | 按量 |

这在代码里的对应关系是：

| 通道 | 承担的模块 | 成本 |
|---|---|---|
| 确定性层 | 文件筛选、13 条 AST 规则、Ruff / Bandit / radon 扫描 | 零 Token |
| LLM 层 | 候选复核（误报过滤）、逻辑/边界问题发现、修复建议 | 按量计费 |
| 评测层 | Harness 驱动真实链路，量化质量与成本 | 评测时计费 |

这条设计原则不是拍脑袋的——它对齐两个工业界已验证的经验：GitHub Copilot 团队公开的成本优化原则（「消除 harness 本可确定性完成的工作」）和阿里 Open Code Review 的设计原则（「确定性逻辑接管高确定性任务」）。

一个具体的例子：`open()` 未使用 `with` 语句，是资源泄漏的经典可疑形态。这种判断需要两半：

- **「哪里出现了不在 with 里的 open 调用」**——纯结构判断，AST 规则负责，零 token；
- **「调用方到底有没有手动 close、异常路径会不会漏」**——需要读控制流做语义推理，LLM 负责。

一半交给零成本的规则，一半交给按需付费的模型——这就是三级分工在单条规则上的微观体现。这条规则（CG005）的设计细节放在 3.3 展开。

## 1.3 全景：一次 `codesage review` 的完整旅程

`pipeline.py` 的 `run_review()` 负责把一次审查串起来。它的模块注释先把五个阶段画出来了：

```text
    扫描（零 Token）
      → 确定性分析（零 Token：AST 规则 + Ruff + Bandit + radon）
      → Agent 循环（Token：复核候选 + 补充发现 + 修复建议）
      → 合并去重（LLM 驳回的候选被过滤）→ 评分 → 落盘
```

展开成一张图：

```text
用户: codesage review <path>
        │
        ▼
① 扫描（零 Token）         scanner + FileFilter → 文件清单 + 跳过原因
        │
        ▼
② 确定性分析（零 Token）    13 条 AST 规则 + Ruff / Bandit / radon → 候选发现
        │
        ▼
③ Agent 循环（LLM）        复核候选（submit / dismiss）+ 补充独立发现
        │                  （记忆压缩、预算控制在这一步自动发生）
        ▼
④ 合并聚合               驳回过滤 → 去重 → 评分 → 报告对象
        │
        ▼
⑤ 输出与落盘              Rich 终端 / Markdown / JSON 导出 → SQLite 落盘
```

每个阶段的归属：

| 阶段 | 做什么 | 代码入口 | 对应篇目 |
|---|---|---|---|
| ① 扫描 | 遍历目录、筛选、统计行数 | `ingest/scanner.py`、`ingest/filters.py` | 第 02 篇 |
| ② 确定性分析 | 13 条规则 + 3 个外部分析器 | `analyzers/` | 第 03 篇 |
| ③ Agent 循环 | 复核候选、补充发现、提修复建议 | `agent/`、`tools/`、`llm/`、`memory/` | 第四、五、六部分 |
| ④ 合并聚合 | 驳回过滤、去重、评分 | `pipeline.py`、`core/models.py` | 本篇 1.4 |
| ⑤ 输出与落盘 | 渲染 / 导出 / SQLite | `cli/`、`memory/store.py` | 第 09 篇 |

有一个值得注意的结构事实：**`run_review()` 在整个代码库里只有两个调用点。**

| 调用位置 | 场景 | 特点 |
|---|---|---|
| `cli/commands/review.py:116` | 用户执行 `codesage review` | 携带事件钩子，实时打印进度 |
| `harness/runner.py` | Harness 批量评测 | 在独立临时工作区中调用（第 07 篇展开） |

第二个调用点用的是**函数内延迟导入**：

```python
    def run(self, tag: str) -> dict:
        """执行评测，返回 summary，并写盘。"""
        from codesage.pipeline import ReviewOptions, run_review
```

这个写法不是随手写的。`harness/` 有一条硬约束（写在 `pipeline.py` 的模块注释里）：**评测必须通过 `run_review()` 驱动真实链路，而不是直接调分析器**——否则评测结果反映的是「分析器的能力」，而不是「用户实际使用时的行为」。延迟导入让「harness 不依赖 agent 内部模块」这条架构纪律在 import 层面也能成立。

## 1.4 领域模型：Finding 是唯一的问题载体

理解了流程，再看数据。整个项目所有模块之间传递的「问题」只有一种类型——`core/models.py` 里的 `Finding`。它的模块注释写得很直白：

```python
"""核心领域模型：Finding / ReviewReport / TokenUsage。

设计约定（解耦的关键）：
- 所有模块之间传递的数据都使用这里的模型：
  分析层（AST 规则 / Ruff / Bandit）与 Agent 层互不认识，
  但产出的都是同一个 Finding，报告层只认 Finding。
- Finding 是唯一的“问题”载体，无论来源是规则还是 LLM。
"""
```

一个 `Finding` 的核心字段：

| 字段 | 类型 | 含义 |
|---|---|---|
| `file` | `str` | 相对工作区根目录的 POSIX 路径 |
| `line_start` / `line_end` | `int` | 1-based 行号范围 |
| `category` | `Category` | 五维度之一：quality / bug / performance / security / best_practice |
| `severity` | `Severity` | critical（P0）/ major（P1）/ minor（P2）/ info（P3） |
| `title` / `description` / `suggestion` | `str` | 标题 / 说明 / 修复建议 |
| `evidence` | `str` | 证据代码行（截取 200 字符） |
| `confidence` | `float` | 置信度 0~1（规则类 0.6~1.0；LLM 提交时由模型给出） |
| `source` | `Source` | 溯源：ast_rule / ruff / bandit / radon / llm |
| `rule_id` | `str` | 规则编号（自研规则 CG001~CG013；LLM 提交的是 `CG-LLM`） |

严重级不只是标签，还直接决定扣分权重：

```python
    @property
    def weight(self) -> int:
        """评分扣分权重（报告总分 100 分起步）。"""
        return {
            "critical": 15,
            "major": 8,
            "minor": 3,
            "info": 1,
        }[self.value]
```

也就是说，报告里的 `score` 就是 `100 - Σ(每条发现的 weight)`，下限截到 0。这个算法简单到一句话能讲清，好处是**任何一个分数都能追到具体是哪几条发现扣的**——评分机制如果不可解释，就没法用来做质量讨论。

Finding 上还有两个值得单独说的**属性**。

**第一个是 `id`——给每条发现一个稳定短 ID**，用于 CLI 里引用（比如 `codesage feedback <finding_id>`）：

```python
    @property
    def id(self) -> str:
        """稳定的短 ID（用于 CLI 反馈与报告引用）。

        使用 SHA1 仅为生成短标识（非安全用途），
        usedforsecurity=False 明确声明这一点（同时消除 Bandit B324 告警）。
        """
        key = f"{self.file}:{self.line_start}:{self.rule_id or self.title}:{self.source.value}"
        return hashlib.sha1(key.encode("utf-8"), usedforsecurity=False).hexdigest()[:8]
```

注意注释里那句「同时消除 Bandit B324 告警」——这是一个很有意思的细节：**项目用 Bandit 扫别人，也得处理 Bandit 扫自己的告警**。`usedforsecurity=False` 是明确的语义声明：这个 SHA1 只用来生成短标识，不承担任何安全职责。

**第二个是 `dedup_key`——去重键**：

```python
    @property
    def dedup_key(self) -> str:
        """去重键：同文件 + 相近行 + 同类别视为同一问题（保留高置信度者）。"""
        return f"{self.file}:{self.line_start // 3}:{self.category.value}"
```

`line_start // 3` 是「相近行」的近似——同一处问题被不同工具报出来的行号常常差一两行（比如 Bandit 报在 `execute` 调用行，规则报在 f-string 拼装行）。整除以 3 是把 3 行以内的偏差归到同一格。

去重的完整逻辑在 `dedup_findings()` 里，它有一条**很克制的规则**：

```python
    groups: dict[str, list[Finding]] = {}
    for f in findings:
        groups.setdefault(f.dedup_key, []).append(f)

    result: list[Finding] = []
    for group in groups.values():
        if len(group) == 1:
            result.extend(group)
            continue
        sources = {f.source for f in group}
        if len(sources) == 1:
            result.extend(group)  # 单一来源：均为独立发现，全部保留
            continue
        best_source = min(sources, key=lambda s: source_priority.get(s, 9))
        result.extend(f for f in group if f.source == best_source)
```

普通的去重是「同一位置只保留一条」，但这里分两种情况：

- **组内只有单一来源 → 全部保留。** 因为同一行上不同规则报的问题可能是不同的东西——比如「裸 except（CG002）」和「异常被吞没（CG003）」经常落在同一个 except 块上，它们是两条独立发现；
- **组内有多个来源 → 只保留优先级最高的。** 比如 Bandit 和自研规则报了同一处 SQL 注入，那是一条问题被两个人说出来了，只留一条。

来源优先级是：`LLM > 自研规则 > Bandit > Ruff > radon`。LLM 排第一是因为它的发现经过语义确认；自研规则排第二是因为「中文描述与修复建议最完整」——这个理由写在代码注释里，很实在：工程决策考虑的不只是正确性，还有输出质量。

## 1.5 小结

- **核心判断**：LLM 只在需要语义推理的环节介入——确定性任务零 Token、半确定性任务短上下文复核、开放任务深度审查。
- **五个阶段**：扫描 → 确定性分析 → Agent 循环 → 合并聚合 → 输出落盘；`run_review()` 全库只有两个调用点（CLI 与 Harness），Harness 用延迟导入保证评测走真实链路。
- **一个领域模型**：`Finding` 是唯一的问题载体，`source` + `rule_id` 记录溯源，`dedup_key` 做跨工具去重，`score` 从 100 起按严重级扣分。
- **去重的克制**：单一来源全保留，多来源只留优先级最高者——避免把「同一处的两条独立问题」误合并。

第 02 篇开始进入具体模块，先看没有任何 token 成本的确定性层：文件怎么被扫出来、怎么被切块、git 变更怎么被解析。
