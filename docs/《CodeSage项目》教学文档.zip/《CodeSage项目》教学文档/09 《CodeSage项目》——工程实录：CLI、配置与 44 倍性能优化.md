# 《CodeSage项目》——工程实录：CLI、配置与 44 倍性能优化

## 9.1 CLI 的形状

四个命令，各管一段：

| 命令 | 职责 | 对应篇目 |
|---|---|---|
| `codesage review <path>` | 审查代码（主入口） | 全部 |
| `codesage eval` | 跑 Harness 评测 / A-B 对比 | 第 07 篇 |
| `codesage history` | 查看历史审查记录与反馈统计 | 落盘（`memory/store.py`） |
| `codesage feedback` | 反馈发现质量 / 管理错题本 | 第 08 篇 |

`review` 的选项表：

| 选项 | 说明 |
|---|---|
| `--no-llm` | 只跑确定性分析（零 Token，无需 API Key） |
| `--changed` | 只审查 git 变更涉及的文件（增量模式） |
| `--profile` | 审查角色：`full` / `security` / `performance` |
| `--format` | 输出格式：`terminal` / `markdown` / `json` |
| `--output` | 导出到文件（配合 `--format`） |
| `--min-severity` | 终端展示的最低严重级 |
| `--fail-on` | CI 退出码阈值（`critical` / `major` / `minor`） |
| `--max-turns` | 覆盖最大轮次（默认取配置） |
| `--quiet` | 安静模式（不打印进度） |

**两个值得展开的选项。**

第一个是 `--fail-on`——CI 集成的最小开关。退出码逻辑：

```python
    # ---- CI 退出码
    if fail_level is not None and any(
        f.severity.weight >= fail_level.weight for f in report.findings
    ):
        raise typer.Exit(1)
```

`--fail-on major` 的语义是：只要报告里有一条 P0 或 P1，退出码为 1——CI 流水线据此拒绝合并。这里复用了严重级的 `weight` 做大小比较（15 > 8 > 3 > 1），和评分用的是同一套序。审计工具融入 CI 的最短路径就是「退出码 + JSON 导出」两件事，两个都做了。

第二个是格式输出的一个隐蔽 bug 修复。`--format json` 直接打印到终端时，Rich 的默认行为会破坏输出：

```python
            # 关闭 Rich 的 markup 解析与自动折行——否则 JSON/Markdown 结构会被破坏
            # （折行会在字符串内引入换行导致 JSON 非法；[xxx] 会被当作标记吞掉）
            console.print(text, markup=False, highlight=False, soft_wrap=True)
```

两个坑：自动折行会在 JSON 字符串**内部**插换行导致解析失败；markup 解析会把代码里 `[xxx]` 样式的文本当成富文本标记吞掉。这个注释是那种「不踩过就不知道」的知识——凡是往终端打印结构化数据的 CLI，都会碰上。

## 9.2 配置系统：三源优先级 + 兜底

配置来自三个源，优先级在 `Settings.settings_customise_sources` 里显式排序：

```python
        """数据源顺序：显式初始化 > 环境变量 > .env > codesage.toml。"""
        sources: list[PydanticBaseSettingsSource] = [
            init_settings,
            env_settings,
            dotenv_settings,
        ]
        toml_path = Path("codesage.toml")
        if toml_path.exists():
            sources.append(
                TomlConfigSettingsSource(settings_cls, toml_file=str(toml_path))
            )
        return tuple(sources)
```

为什么 `codesage.toml` 用「存在才追加」而不是写死配置项？注释里也有答案——「避免文件不存在时的配置告警」。项目配置文件是可选的，没有它不应该产生噪音。

环境变量命名走 pydantic-settings 约定的双下划线嵌套：`CODESAGE_LLM__API_KEY` → `settings.llm.api_key`。对用户还有一个体验兜底——**没设 `CODESAGE_` 前缀也认**：

```python
# 常见环境变量兜底顺序（用户不必记住 CODESAGE_ 前缀）
_FALLBACK_API_KEY_ENVS = ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "DASHSCOPE_API_KEY")
```

```python
    settings = Settings()
    if not settings.llm.api_key:
        for env_name in _FALLBACK_API_KEY_ENVS:
            value = os.environ.get(env_name, "").strip()
            if value:
                settings.llm.api_key = value
                break
    return settings
```

顺带把 `llm_configured` 讲清楚：这是 `Settings` 上的一个属性（`bool(self.llm.api_key.strip())`），是「降级模式」的开关——三大入口（review 命令、pipeline、eval 命令）都用它决定「走完整链路还是确定性层」。**「没配置 key 也能用」不是偶然，是被三处判断有意保住的能力**：审查降级为确定性分析并明确提示，评测降级为 `--mock`。

## 9.3 故障容错哲学：主流程不能死于辅助设施

把散在各处的容错设计收集起来，会发现一条统一的哲学。

| 故障 | 处理 | 位置 |
|---|---|---|
| 未配置 API Key | 降级确定性分析，明确提示 | `cli/commands/review.py`、`pipeline.py` |
| LLM 调用失败 | `LLMError` → 循环以 `error` 状态带回已有发现 | `agent/loop.py` |
| 工具执行异常 | 转 `ERROR: ...` 文本回填，模型自纠 | `agent/registry.py` |
| 压缩失败（返回空/异常） | 保持原状，宁可占 token | `memory/working.py` |
| 事件钩子抛异常 | 吞掉，不影响主循环 | `agent/loop.py` |
| 错题本读取失败 | 空经验块继续 | `pipeline.py` |
| 外部分析器未安装 | 过滤掉，其余照跑 | `pipeline.py` |
| git diff 解析失败 | 静默回退全量（`--changed` 不报错） | `ingest/git_diff.py` |
| SQLite 落盘失败 | 忽略（只读目录也不中断审查） | `pipeline.py` |
| 单条 AST 规则异常 | 跳过该规则 | `analyzers/ast_rules.py` |

落盘那一条的代码形态很典型：

```python
    # ---------------------------------------------------------- 5. 落盘
    if store is not None:
        try:
            review_id = store.save_review(report)
            report.metadata["review_id"] = review_id
        except Exception:  # noqa: BLE001 - 落盘失败不致命
            pass
        finally:
            store.close()
```

连 `_open_store` 自己都是「失败返回 None」：

```python
def _open_store(workspace: Path) -> Store | None:
    """打开项目级存储（失败返回 None，不影响审查主流程）。"""
```

这条哲学可以浓缩成一句话：**辅助设施（落盘、观测、记忆增强、外部工具）的任何失败，都不能把主流程（一次审查）带下水。** 判断哪些设施是「辅助」、哪些是「主干」，然后让辅助侧全部可降级——这是让一个多模块系统在真实环境里「皮实」的关键。

## 9.4 性能实录：44 倍提速是怎么来的

这是整个项目最有工程叙事感的一段——因为优化的起点和终点都是真实测量。

**起点：一次尴尬的自举审查。** 用 CodeSage 审查自己的源码（62 个文件），全量审查耗时 **92.7 秒**。一个「AI 代码审查工具」看不了自己的代码，说不过去。

**定位：cProfile 逐层剖析。** 耗时分布出来后，三个大头浮出水面，对应的修复也都各自有据。

| 阶段 | 优化前 | 优化后 | 手段 |
|---|---|---|---|
| Bandit 扫描 | 90s+ | ~8s → 1.5s | 逐文件子进程调用（每次 ~1.5s 启动成本）→ 单次批量扫描目录 |
| Ruff 扫描 | ~7s | ~0.2s | 同上 + 直接扫描真实目录（不再复制源码） |
| 临时目录写删 | ~7s | 0s | cProfile 显示 `nt.remove`/`nt.rmdir` 删除 62 个文件占 6.7s（Windows 文件系统挂钩开销）→ 改为零临时文件设计 |
| **总耗时** | **92.7s** | **2.1s** | **约 44 倍提速** |

三个修复的代码侧注释都留了下来，值得逐条读——它们记录了「为什么」。

**修复一：Bandit 批量扫描。** 问题根源是子进程启动成本：

```python
"""Bandit 集成：安全漏洞扫描（SQL 注入 / 命令注入 / 反序列化等）。
...
性能设计（批量模式）：
Bandit 每次调用要付出解释器启动 + 依赖导入的成本（约 1.5s），
逐文件调用在 60+ 文件的仓库上会耗时 90 秒以上。
run_batch 把所有源码写入临时目录（保持相对路径结构），
一次 `bandit -r` 完成扫描——这是自举审查（用 CodeSage 扫自己）发现的优化点。
"""
```

62 个文件 × 1.5 秒 ≈ 93 秒——**耗时几乎全是解释器启动，和代码本身毫无关系**。批量模式把 62 次调用合并成 1 次 `bandit -r`（递归扫目录），启动成本被摊薄到趋近于零。

**修复二：Ruff 的零临时文件设计。** 这一步是更细的观察：

```python
        """批量扫描。

        性能设计（cProfile 实测的优化结论）：
        - 临时目录模式在 Windows 下有隐藏成本：删除 62 个文件实测 6.7s
          （nt.remove/nt.rmdir，杀毒软件与文件系统挂钩导致）；
        - 因此提供 base_dir 参数：源码本来就在磁盘上时（pipeline 与 eval
          的全部真实场景），直接扫描真实目录——零临时文件、零清理成本。
        临时目录模式仅作兜底（调用方仅有内存源码时）。
        """
```

最初的「批量」实现是把源码写进临时目录再扫——但在 Windows 上，**删除 62 个临时文件的系统调用开销实测 6.7 秒**（杀毒软件与文件系统过滤驱动对每个文件的删除都要插一脚）。这个发现只有 cProfile 能给出——你盯着代码看一万遍也想不通「删文件为什么这么慢」。

解法是一次接口的重新审视：**源码本来就在磁盘上**（审查真实项目时），那为什么要把它们复制到临时目录再扫？于是 `run_batch` 增加 `base_dir` 参数——有真实目录就直接扫真实目录；只有「调用方手里仅有内存中的源码字符串」时才回退临时目录模式。零临时文件、零清理成本。这个 `base_dir` 参数就是第 03 篇的 3.4 里 pipeline 调用批量分析器时传的那个。

**修复三：方法论。** 这次优化最值得学的不是任何一行代码，而是流程本身——README 里专门总结了这一点：

> 这次优化本身也是评测驱动开发的例证：先有量化基线（Harness 记录每次耗时），再做剖析，最后用数据验证收益。

三步都可以复述到面试里：**有基线**（92.7s 是个被记录下来的数字）→ **有剖析**（不猜，cProfile 说话；「删文件 6.7 秒」这种反直觉结论只能来自测量）→ **有验证**（改完 2.1s，同样是测出来的）。另外注意这三个修复的共同特征：**没有一个涉及算法**——全是「进程模型」和「I/O 模型」层面的结构问题。性能优化的大头往往在这里，不在算法。

## 9.5 测试策略：85 个用例都在守什么

项目当前 **9 个测试文件、85 个用例，全量跑完 2.54 秒**。测试不快不慢、覆盖很聚焦——每个文件守一类事实：

| 测试文件 | 守什么 | 代表机制 |
|---|---|---|
| `test_agent_loop.py` | 循环的每一步：正常流程 / 错误回填 ×3 / 停止 ×2 / 预算熔断 / 压缩 ×2 | Mock 客户端驱动 |
| `test_ast_rules.py` | 每条规则「正例 + 反例」成对 | 见下方引文 |
| `test_noise_control.py` | 误报控制回归（3.5 的事故档案） | 豁免生效 + 不放水 |
| `test_models.py` | 去重策略（跨来源合并 / 同来源保留 / 优先级） | 见下方背景 |
| `test_metrics.py` | 软匹配器（行区间 + 关键词）与聚合 | 评价系统自己也要被测 |
| `test_memory.py` | 三区组装 / 压缩触发条件 / 压缩失败保护 | 「信息优先于成本」 |
| `test_registry.py` | schema 生成 / 执行容错 / 参数过滤 | 反射生成的可信度 |
| `test_ingest.py` | 扫描过滤 / 大文件跳过 / gitignore / 切块 / diff 区间 | 感知层全链 |
| `test_tokenizer.py` | 估算器（CJK / ASCII / 消息开销） | 预算基础设施 |

三处最值得引用的测试注释。

**其一：为什么正反例必须成对**（`test_ast_rules.py`）：

```python
"""AST 规则引擎测试：每条规则 正例 + 反例 成对出现。

为什么正反例成对：规则的"漏报"与"误报"是两个独立缺陷，
只用正例测不出误报（over-triggering）。
"""
```

这条纪律的实践形态就是成对的函数：`test_cg001_mutable_default_positive` 断言 `def f(x=[])` 被抓到；`test_cg001_mutable_default_negative` 断言 `def f(x=None): x = x or []`（正确的写法）**不会**被误抓。13 条规则全部按这个格式写。

**其二：循环测试完全靠 Mock 驱动。** `test_agent_loop.py` 的头部注释：

```python
"""Agent 循环测试：Mock 客户端驱动，不依赖网络与 API Key。

覆盖（对应规划文档的循环设计要点）：
- 工具调用 → 结果回填 → 正常结束
- 未知工具 / 参数错误 → ERROR 文本回填（模型可自纠）
- 轮次上限 / 无进展 → 策略停止
- Token 预算 → 熔断
- 软阈值 → 回合边界压缩
"""
```

`MockLLMClient` 按预置的响应序列返回，并且**记录每次请求的完整消息快照**——测试可以断言「第二轮请求里有没有带着 ERROR 的 tool 消息」「压缩是否发生在正确的时机」。这是自研内核的直接红利：循环的所有依赖（client / registry / memory / budget）都是构造参数，替换任何一个都不需要打桩框架。**一个 150 行的循环 + 一个 30 行的 Mock = 九个场景的全覆盖**——如果用框架，这层测试会难写得多。

另外注意测试里对压缩时机的精确参数设计（`test_soft_threshold_triggers_compression` 的注释）：用「3000 字符 system 消息、100 字符工具结果、context_window=1500」构造出「第 2 轮末恰好落入 SOFT 且活跃区轮数足够」的确定性场景——**测试也在和估算器的算术打交道**，这说明估算器的行为是可预测、可依赖的。

**其三：去重策略的测试来自一次真实的翻车**（`test_models.py` 的头部注释）：

```python
"""去重策略测试：跨来源合并、同来源保留、优先级顺序。

背景：demo_target 演示中发现 Bandit 的英文发现（B307 blacklist）
把自研规则的中文发现（CG011 eval，含具体修复建议）挤掉了——
本文件锁定修复后的去重行为。
"""
```

这是第 03 篇的 3.5「208 条噪音」之外的第二起真实事故：在 demo 演示中发现，同一行上 Bandit 的 B307 和自研 CG011 同时报了 `eval`，而去重的取舍逻辑把「带具体修复建议的中文发现」挤掉了。修复方案就是现在看到的来源优先级（自研规则 > Bandit）——**第 01 篇的 1.4 讲的那套优先级，就是从这次事故里长出来的**。事故 → 修复 → 用测试锁死，这是项目里重复出现的改进模式。

## 9.6 小结

- **CLI**：四个命令各司其职；`--fail-on` 退出码 + JSON 导出构成 CI 集成；结构化输出要关 Rich 的折行与 markup（两个隐蔽坑）。
- **配置**：显式 > 环境变量 > .env > codesage.toml；`DEEPSEEK_API_KEY` 等常见变量名兜底；「未配置也能用」是被三处判断保住的正式能力。
- **容错哲学**：辅助设施（落盘/观测/外部工具/记忆增强）失败一律可降级，主流程不可死于附属功能——十处容错，一个原则。
- **44 倍提速**：92.7s → 2.1s；三个修复全部在进程/I/O 模型层面（批量子进程、零临时文件）；方法论是「基线 → 剖析 → 验证」。
- **测试**：85 个用例守四类事实——循环行为（Mock 驱动）、规则正反例、事故回归（噪音控制/去重）、基础设施（估算器/匹配器）。
