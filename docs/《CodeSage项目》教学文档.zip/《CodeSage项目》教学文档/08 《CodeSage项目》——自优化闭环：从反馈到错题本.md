# 《CodeSage项目》——自优化闭环：从反馈到错题本

## 8.1 三个环：规划与落地

自优化的完整设计是三个环（来自项目规划）：

| 环 | 内容 | 规划优先级 | 实际落地状态 |
|---|---|---|---|
| 环 1 | 反馈采集 → 错题本 → Prompt 注入 | 必做 | **已闭环**（feedback CLI → lessons 表 → 系统提示注入） |
| 环 2 | Prompt 版本管理 + 效果绑定 | 必做 | **半落地**：`PromptRegistry` 与 `prompts` 表已实现，但主链路尚未接入（见 8.4 诚实标注） |
| 环 3 | 参数自适应（压缩阈值、路由自动调优） | 选做 | 未实现，设计思路保留（v2 方向） |

环 1 的闭环在代码里的完整链路：

```text
codesage feedback <id> -v wrong     ← 人工标记一条误报
        │
        ▼
feedback 表（SQLite）               ← {finding_id, verdict, category, file, title, note}
        │
        ▼
codesage feedback --mine            ← LessonBook.mine_from_feedback() 提炼
        │
        ▼
lessons 表                          ← 【误报案例】file title：note
        │
        ▼
下次审查时 pipeline 自动执行：
  LessonBook(store).few_shot_block() → build_system_prompt(lessons_block=...)
        │
        ▼
系统提示词里多了一段「## 历史经验（来自反馈错题本，供参考）」
```

## 8.2 反馈采集：一句话把误报变成资产

反馈的三种判定在 `optim/feedback.py` 里：

```python
VALID_VERDICTS = ("wrong", "right", "missed")

_VERDICT_ZH = {
    "wrong": "误报（判定有误）",
    "right": "确认（确实有问题）",
    "missed": "漏报（应该发现但没发现）",
}
```

「确认（right）」看起来只是点赞——它的用处是作为对照组数据；真正的优化原料是 `wrong`（误报）和 `missed`（漏报）。

CLI 侧的体验是「报告里看到的 8 位短 ID → 原样贴进命令」：

```bash
codesage feedback <finding_id> -v wrong -n "这个场景下是刻意的"   # 标记误报
codesage feedback --mine     # 提炼错题本（下次审查自动注入经验）
codesage feedback --show     # 查看错题本
```

反馈记录时有一个体贴的细节——**去历史审查里把发现的完整上下文找回来**：

```python
def _locate_finding(store: Store, finding_id: str) -> dict | None:
    """在最近 20 次审查中定位一条发现的完整信息。"""
    for row in store.recent_reviews(limit=20):
        for finding in store.get_review_findings(int(row["id"])):
            if str(finding.get("id")) == finding_id:
                return finding
    return None
```

用户在终端敲命令时只需要提供 8 位 ID；`category` / `file` / `title` 这些上下文从最近 20 次审查的落盘记录里自动补齐。工具对人的要求越少，人越愿意反馈——反馈频率是自优化系统的生命线。

## 8.3 错题本：从反馈到注入

提炼逻辑在 `LessonBook.mine_from_feedback()`：把反馈表里的 `wrong` 变成「【误报案例】…」、`missed` 变成「【漏报案例】…」，按「kind + content」去重后写入 `lessons` 表：

```python
            if verdict == "wrong":
                content = (
                    f"【误报案例】{fb.get('file', '?')} "
                    f"{fb.get('title', '?')}"
                    + (f"：{fb.get('note')}" if fb.get("note") else "")
                )
```

生成注入文本的是 `few_shot_block()`，它干两件事：**限条数**（默认 6 条）和**限总字符**（1200）：

```python
    def few_shot_block(self, limit: int = 6) -> str:
        """生成注入 prompt 的经验块（控制条数与总字符数）。"""
        lessons = self.all(limit=limit)
        if not lessons:
            return ""
        lines: list[str] = []
        used = 0
        for lesson in lessons:
            prefix = "误报" if lesson.kind == LESSON_FALSE_POSITIVE else "漏报"
            line = f"- [{prefix}] {lesson.content}"
            if used + len(line) > MAX_BLOCK_CHARS:
                break
            lines.append(line)
            used += len(line)
        return "\n".join(lines)
```

注入的落点在 `pipeline.py`——审查开始时读取错题本：

```python
        lessons_block = ""
        if store is not None:
            try:
                from codesage.optim.lessons import LessonBook

                lessons_block = LessonBook(store).few_shot_block()
            except Exception:  # noqa: BLE001 - 错题本读取失败不影响审查
                lessons_block = ""
```

然后经 `build_system_prompt()` 的 `lessons_block` 槽位进入系统提示，标签是「## 历史经验（来自反馈错题本，供参考）」——**「供参考」三个字是刻意的**：经验是提示而非命令，不能让它绑架模型的独立判断。

注意外层那个 `try/except`——错题本读取失败，审查以「无经验」模式照常进行。整条链路上每一个可选组件都是这个待遇（第 06 篇压缩器、第 09 篇落盘），这是一致的设计语言。

## 8.4 Prompt 版本管理：已实现，未接线

环 2 的目标是「让 prompt 迭代有版本、有数据、可回滚」。`optim/prompts.py` 的 `PromptRegistry` 已经实现，版本号的设计很干净——**内容哈希前 8 位，内容相同即同版本**：

```python
    @staticmethod
    def version_of(template: str) -> str:
        """内容哈希（前 8 位）作为版本号——内容相同即同版本。

        非安全用途的短标识，usedforsecurity=False。
        """
        return hashlib.sha1(
            template.encode("utf-8"), usedforsecurity=False
        ).hexdigest()[:8]
```

`register()` 会把模板写入 `prompts` 表（profile / version / template / note，`add_prompt_version` 自带幂等去重）。

**诚实标注**：全项目搜 `PromptRegistry`，引用只出现在 `optim/__init__.py` 的导出和它自己的定义里——**`register()` 在审查主链路中没有任何调用点**。也就是说，当前 `codesage eval --compare tagA,tagB` 对比两次评测时，结果里还没有自动带上「本次用的 prompt 是哪个版本」。环 2 缺的是最后一段接线：pipeline 组装完系统提示词后登记版本、评测 summary 里记录版本号。基础设施（注册表 + 表结构 + 幂等写入）都已就位并有清晰接口，接线是下一步的活。

这种「实现如实、接线未到」的中间态值得专门标注——它和「没实现」是两回事，和「已完成」也是两回事。

## 8.5 防过拟合纪律

自优化系统最大的风险不是不好用，而是**好用到过拟合**：错题本里的例子最终把模型调成「只认识这几个案例」。模块注释里写下了三条纪律：

```python
"""防过拟合纪律（面试要点）：
- 注入的经验条数有上限（few_shot_block 的 limit）；
- 效果必须通过 Harness A/B 评测验证（不能"感觉变好了"）；
- 评测数据集拆分调优集/验证集（见 README 的评测章节）。
"""
```

三条对应的机制：

1. **上限**：≤6 条 & ≤1200 字符——经验池有物理上限，不可能无限堆案例；
2. **A/B 验证**：所有优化的准入标准是「`eval --compare` 上的检出/误报不回归」。改了 prompt、加了错题本，都要跑一遍对比——**「感觉变好了」不是变更理由，数据是**；
3. **数据集拆分**：调优集（用来迭代 prompt 的案例）与验证集（用来验收的案例）分开——如果反复对着全集调，调优集上的提升可能只是记住了案例。规划文档给的拆分比例是 7:3。

**诚实标注**：纪律本身是明确的、写在文档与模块注释里的；「拆分机制」当前还是手工流程（数据集只有 5 个种子案例，拆分没有统计意义）。它和环 2 的接线一起，构成「数据集扩充到 25-30 个案例」这个待办的两翼。

## 8.6 小结

- **环 1 已闭环**：`feedback` 采集（三态判定 + 自动补上下文）→ `lessons` 提炼（误报/漏报）→ 系统提示注入（限 6 条 / 1200 字符、标注「供参考」）。
- **环 2 半落地**：`PromptRegistry`（内容哈希作版本号）与 `prompts` 表已实现，但 `register()` 尚未接入主链路——评测与 prompt 版本的自动绑定是下一步。
- **环 3 未实现**：参数自适应保留为 v2 方向。
- **贯穿原则**：反馈失败、错题本读取失败都不阻断审查；所有优化必须过 A/B——**数据是唯一的守门人**。

第 09 篇收尾，讲那些让整个项目「能跑、跑得快、坏不了」的工程细节——包括一个 44 倍性能优化的完整案例。
