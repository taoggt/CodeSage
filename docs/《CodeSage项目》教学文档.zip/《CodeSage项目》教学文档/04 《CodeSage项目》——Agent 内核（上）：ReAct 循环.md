# 《CodeSage项目》——Agent 内核（上）：ReAct 循环

## 4.1 循环骨架

`agent/loop.py` 是整个项目的灵魂。它在模块 docstring 里先把骨架画了出来：

```text
循环骨架（约 150 行的核心）：

    while True:
        1. 估计当前上下文 token 量 → 检查预算状态（OK/SOFT/HARD/ABORT）
        2. ABORT → 熔断退出（输出已有发现）
           HARD  → 调用前强制压缩
        3. 调用 LLM（带工具 schema）
        4. 无 tool_calls → 模型认为完成，正常结束
           有 tool_calls → 逐个执行并回填结果（role=tool）
        5. 回合末：轮次/进展检查；SOFT → 回合边界压缩
```

说「约 150 行」指的是核心逻辑部分——`loop.py` 连注释、数据类和辅助设施一共 227 行。另外三条设计要点也在 docstring 里写明了：

> - 循环不认识"压缩细节"与"发现收集"（依赖注入）——关注点分离；
> - 工具错误不抛出，以文本回填让模型自我纠正；
> - 每一步都通过 on_event 钩子可观测（CLI 进度、调试、评测 trace）。

这三条各自的展开，就在下面几节。

**为什么用「原生 function calling」而不是「文本解析 ReAct」？**

经典的 ReAct 论文式实现是让模型输出 `Thought: ... / Action: xxx / Action Input: ...` 的文本，程序用正则解析。CodeSage 没有走这条路——它用 OpenAI 协议的 `tools` 参数，让模型通过结构化的 `tool_calls` 字段返回调用意图：

| 维度 | 文本解析 ReAct | 原生 function calling |
|---|---|---|
| 解析 | 正则匹配，模型加一个换行格式就崩 | 协议层保证结构化，无解析器 |
| 参数 | 自由文本，得自己约定格式 | JSON Schema 校验 |
| 可靠性 | 低（prompt 一改格式就变） | 高（模型侧原生支持） |
| 可调试 | 出错时分不清是模型问题还是解析问题 | 每一步都有明确数据结构 |

这是「不重复造轮子」原则的一次应用：**协议层提供的标准能力（结构化工具调用）用现成的，项目核心竞争力（循环控制、压缩时机）才自研。** 选 DeepSeek 作为默认模型的一个前提条件，就是它稳定支持 function calling。

## 4.2 run() 逐段讲解

进入 `AgentLoop.run()`。方法签名的第一句注释就定了一个重要约定：

```python
    def run(self, initial_messages: list[dict[str, Any]]) -> AgentResult:
        """执行循环直到结束。

        initial_messages 会被冻结（系统提示 + 任务简报），循环内不再改动。
        """
        self._memory.freeze(initial_messages)
        state = AgentState()
        result = AgentResult()
        self._emit("start", {"tools": self._registry.names()})
```

「冻结」是记忆系统的第一个动作：系统提示 + 任务简报进入冻结区（第 06 篇展开三区模型），循环内不会再被改动——跨轮次完全不变的内容，才有机会命中模型的 prompt 缓存。

然后进入主循环。**第一段：调用前的预算检查。**

```python
        while True:
            # ---- 1. 预算检查（调用前）
            context_tokens = self._estimate_context()
            budget_state = self._budget.state(context_tokens)
            self._emit(
                "context",
                {
                    "turn": state.turn,
                    "tokens": context_tokens,
                    "ratio": round(self._budget.ratio(context_tokens), 3),
                    "state": budget_state.value,
                    "messages": len(self._memory.build()),
                },
            )

            if budget_state == BudgetState.ABORT:
                result.status = "aborted"
                result.stop_reason = (
                    f"Token 预算熔断（使用率 ≥ {int(self._budget_ratio_abort * 100)}%），"
                    "输出已有发现"
                )
                break
            if budget_state == BudgetState.HARD:
                self._compress(context_tokens)
```

每一轮先估计「当前组装出来的消息列表大概占多少 token」，查一下状态。

- `ABORT`：直接熔断退出——宁可输出不完整的报告，也不让下一次 API 调用因为超限失败把整个审查搞崩（第 06 篇讲为什么这样设计）；
- `HARD`：在调用模型**之前**强制压缩——不压缩的话，这一轮可能根本塞不进上下文窗口。

注意这里同时发射了一个 `context` 事件，载荷里带着轮次、token 数、使用率、状态、消息条数——CLI 的进度打印、调试、评测 trace 都消费这同一个事件流。

**第二段：调用 LLM，错误包装。**

```python
            try:
                response = self._client.chat(
                    self._memory.build(),
                    tools=self._registry.schemas(),
                    model=self._model,
                )
            except LLMError as exc:
                result.status = "error"
                result.stop_reason = f"LLM 调用失败：{exc}"
                break
```

`self._memory.build()` 是「组装当前完整消息序列」（冻结区 + 摘要 + 活跃区，第 06 篇展开），`self._registry.schemas()` 是全部工具的 JSON Schema。客户端只抛 `LLMError` 一种异常（实现细节见第 06 篇的 LLM 客户端一节），循环统一处理为 `error` 状态退出。

**第三段：分支——模型还调工具吗？**

这是 ReAct 循环的唯一分岔点。**没有 tool_calls**，意味着模型认为任务完成：

```python
            # ---- 3a. 无工具调用 = 模型认为任务完成
            if not response.has_tool_calls:
                self._memory.append(
                    {"role": "assistant", "content": response.content or ""}
                )
                result.status = "finished"
                result.stop_reason = "模型主动结束"
                result.final_message = response.content or ""
                self._emit("finish", {"message": response.content[:200]})
                break
```

**有 tool_calls**，则回填 assistant 消息，然后逐个执行工具、把结果以 `role=tool` 消息回填：

```python
            # ---- 3b. 有工具调用：回填 assistant 消息 → 逐个执行工具
            self._memory.append(assistant_message_with_tool_calls(response))
            call_names = [tc.name for tc in response.tool_calls]
            self._emit("tool_calls", {"turn": state.turn + 1, "names": call_names})

            for tc in response.tool_calls:
                output = self._registry.execute(
                    tc.name,
                    tc.arguments,
                    max_result_chars=self._config.max_tool_result_chars,
                )
                self._memory.append(tool_result_message(tc.id, output))
                state.tool_calls_total += 1
                self._emit(
                    "tool_result",
                    {"name": tc.name, "preview": output[:120].replace("\n", " ")},
                )
```

这段就是 function calling 协议的完整闭环：assistant 消息（带 `tool_calls`）→ 本地执行 → `role=tool` 结果消息（带 `tool_call_id` 配对）→ 下一轮请求。协议要求「tool 消息必须能找到对应的 tool_call」——这个约束在第 06 篇讲压缩时会再次出现（压缩的切割点必须保证配对不断）。

还有一个细节：`max_tool_result_chars=self._config.max_tool_result_chars`（默认 6000）。工具输出在进入上下文之前有一道硬截断——**上下文控制不靠事后补救，靠进场前守门**。

**第四段：回合末的检查与软压缩。**

```python
            # ---- 4. 回合末：进展记录 + 停止检查 + 软阈值压缩
            state.turn += 1
            if self._findings_counter is not None:
                state.findings_history.append(self._findings_counter())

            should_stop, reason = self._policy.check(state)
            if should_stop:
                result.status = "stopped"
                result.stop_reason = reason
                break

            after_tokens = self._estimate_context()
            if self._budget.state(after_tokens) in (BudgetState.SOFT, BudgetState.HARD):
                self._compress(after_tokens)
```

一轮结束，做三件事：

1. **记进展**：把「当前累计发现数」追进 `findings_history`——这是「无进展检测」的原料（第 05 篇讲停止策略怎么用它）；
2. **查停止**：策略说停就停；
3. **软压缩**：重新估计 token 量，到了 SOFT 或 HARD 就在**回合边界**压缩——此时当前推理已经完成，压缩不会打断它。这就是「SOFT 在回合末、HARD 在调用前」的完整逻辑：**同一个压缩动作，在两个不同的时机被触发，服务于两种不同的紧迫程度**。

循环退出后收尾，把统计信息归集到 `AgentResult`：

```python
        result.turns = state.turn
        result.tool_calls_total = state.tool_calls_total
        result.usage = self._budget.usage
        result.compress_events = self._compress_count
        self._emit("end", {"status": result.status, "reason": result.stop_reason})
        return result
```

## 4.3 四个退出路径

把循环里所有 `break` 归拢起来，一共四种退出方式，对应 `AgentResult.status` 的四个取值：

| 状态 | 触发条件 | stop_reason 示例 | 含义 |
|---|---|---|---|
| `finished` | 模型不再调用工具 | 模型主动结束 | 正常完成 |
| `stopped` | 轮次上限 / 连续无进展 | 达到轮次上限（12 轮） | 策略停止 |
| `aborted` | token 使用率 ≥ 95% | Token 预算熔断（使用率 ≥ 95%），输出已有发现 | 止损退出 |
| `error` | LLM 调用失败 | LLM 调用失败：... | 异常退出 |

这四种状态最后都会落盘进报告（`ReviewReport.stop_reason`），会显示在终端报告的「结束：xxx」里。**让「这次审查为什么结束」变成报告的一等数据**——用户看到一份只查了三轮就结束的报告时，能立刻知道是被熔断的还是模型自己收的工。

`AgentResult` 里的统计字段也是评测的原料：`turns`（轮次）、`tool_calls_total`（工具调用总数）、`usage`（token 用量）、`compress_events`（压缩次数）。第 07 篇的评测指标里，`compress_events` 会用来证明「压缩机制真的在工作」。

## 4.4 依赖注入与可观测性

回看 `AgentLoop` 的构造函数，它要求的东西很有讲究：

```python
    def __init__(
        self,
        *,
        client: Any,  # LLMClient 或兼容对象（Mock 亦可）
        registry: ToolRegistry,
        memory: WorkingMemory,
        budget: TokenBudget,
        estimator: TokenEstimator,
        model: str,
        policy: StopPolicy | None = None,
        config: LoopConfig | None = None,
        compressor: Compressor | None = None,
        findings_counter: Callable[[], int] | None = None,
        on_event: EventHook | None = None,
    ) -> None:
```

| 注入项 | 职责 | 不注入会怎样 |
|---|---|---|
| `client` | LLM 调用（真实或 Mock） | 必填；Mock 让循环可测 |
| `registry` | 工具注册表 | 必填 |
| `memory` | 三区记忆 | 必填 |
| `budget` / `estimator` | 预算与估算 | 必填 |
| `compressor` | 压缩执行器（LLM 实现） | 不注入时压缩是空操作（`_compress` 直接 return） |
| `findings_counter` | 读取「当前发现数」 | 不注入时不记进展，无进展检测失效 |
| `on_event` | 事件钩子 | 不注入时静默 |

这个设计的关键在 `compressor` 和 `findings_counter` 两个参数的类型上：

```python
# 压缩器：接收"中间区消息列表"，返回结构化摘要文本（由外部注入 LLM 实现）
Compressor = Callable[[list[dict[str, Any]]], str]
```

`Compressor` 是一个函数类型，它的实现（调 LLM 做摘要）在 `pipeline.py` 里组装、在 `memory/working.py` 里被执行——**循环只负责在最合适的时机喊一声「该压缩了」，完全不知道压缩内部是 LLM 调用、摘要长什么样**。`findings_counter` 同理：循环只是每轮末问一句「现在有几条发现了？」，不知道发现存在哪个列表里。

这就是 docstring 里那句「循环不认识压缩细节与发现收集」的字面含义——**关注点分离不是口号，是构造函数的参数表**。

可观测性则统一走一个出口：

```python
    def _emit(self, event: str, payload: dict[str, Any]) -> None:
        if self._on_event is not None:
            try:
                self._on_event(event, payload)
            except Exception:  # noqa: BLE001 - 事件钩子异常不影响主循环
                pass
```

钩子异常被吞掉的理由和前面一样：**观测设施不能反噬主流程**。用户传了一个会抛异常的进度打印函数，审查照样跑完——只是没有进度而已。

事件流的完整性值得单独看一眼。一次审查过程中会依次发射：`start`（工具清单）→ `context`（每轮）→ `tool_calls` / `tool_result`（每轮）→ `compress`（每次压缩）→ `finish` / `end`（收尾）。CLI 的进度打印器（`cli/commands/review.py` 的 `_make_progress_printer`）就是这些事件的消费者，把其中的五个翻译成人话：

```text
› 扫描完成：62 个文件（跳过 8）
› 确定性分析（ruff/bandit/radon）：133 条候选发现
› 第 3 轮工具调用：read_file, submit_finding
› 记忆压缩触发（移除 6 条消息，保留 8 条）
› 上下文 51200 tokens（80%）
```

## 4.5 小结

- **循环五步**：预算检查 → LLM 调用 → 无工具则结束 / 有工具则执行回填 → 回合末检查 → 按需压缩。
- **协议选择**：原生 function calling 而非文本解析 ReAct——结构化、可校验、可调试；框架层标准能力用现成的，核心控制逻辑自研。
- **四个退出路径**：finished / stopped / aborted / error，全部落进报告的 `stop_reason`。
- **依赖注入**：压缩与发现收集都是「外部函数」，循环不认识它们的具体实现；事件钩子异常不影响主流程。
- **上下文守门**：工具结果进场前就有硬截断（`max_tool_result_chars`，默认 6000 字符）。

循环会转之后，下一个问题是：它转起来时手里有什么「手」可用、什么时候该「刹车」、以及它看到的提示词长什么样。这是第 05 篇。
