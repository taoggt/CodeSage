# 《CodeSage项目》——确定性层（下）：13 条规则与 3 个外部分析器

## 3.1 规则引擎的三件套

`analyzers/ast_rules.py` 是这个项目最大的单文件（631 行），也是「零 Token」资产的所在。它由三个基础件撑起：

**第一件：`RuleContext`——规则执行的上下文。**

它干两件事：给规则提供源码行文本（`line_text()` 查第 N 行），以及**封装 Finding 的构造**（`make_finding()`）。规则实现只需要关心「检测逻辑」，不用关心 Finding 的字段怎么填：

```python
    def make_finding(
        self,
        node: ast.AST,
        *,
        rule_id: str,
        title: str,
        description: str = "",
        suggestion: str = "",
        severity: Severity = Severity.MINOR,
        category: Category = Category.QUALITY,
        confidence: float = 1.0,
        include_evidence: bool = True,
    ) -> Finding:
        lineno = int(getattr(node, "lineno", 1) or 1)
        endline = int(getattr(node, "end_lineno", lineno) or lineno)
        evidence = self.line_text(lineno) if include_evidence else ""
```

行号直接从 AST 节点取（`lineno` / `end_lineno`），证据行从源码取——所以**规则报出来的行号天然精确**，不存在 LLM 那种「行号幻觉」。这正是确定性层的价值所在。

**第二件：`Rule` / `NodeRule`——规则的两种写法。**

`Rule` 是抽象基类，只有一个约定：实现 `check(tree, ctx) -> list[Finding]`。

`NodeRule` 是给「按节点类型逐节点检查」的规则准备的模板：

```python
class NodeRule(Rule):
    """按节点类型遍历的规则模板。

    子类声明 node_types 并实现 visit_node(node, ctx)，
    引擎负责遍历与分发。若规则需要整树上下文（如 parent 链），
    可直接重写 check()。
    """
```

子类声明 `node_types`（比如 `(ast.ExceptHandler,)`），再实现 `visit_node`，遍历与分发由基类完成。大多数规则都是「给定一种节点，判断它是否可疑」——这个模板方法模式让**13 条规则的实现都短小且形状一致**。

而需要整树上下文的规则（比如 CG005 要知道「open 调用在不在 with 里」，得往上找父节点），就按注释给的逃生口，直接重写 `check()`——两种写法并存，模板只管合适的 80%。

**第三件：引擎的两个保护。**

`RuleEngine.run()` 承担「单次解析、多规则执行」，它有两个保护分支。

保护一：**语法错误**。文件解析不了时，报告一条特殊的 `CG000`：

```python
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            return [
                Finding(
                    file=filename,
                    line_start=exc.lineno or 1,
                    line_end=exc.lineno or 1,
                    category=Category.BUG,
                    severity=Severity.MAJOR,
                    title=f"语法错误：{exc.msg}",
                    description=f"文件无法解析（{exc.__class__.__name__}），请先修复语法。",
                    source=Source.AST_RULE,
                    rule_id="CG000",
                )
            ]
```

保护二：**单条规则的异常隔离**。

```python
        for rule in self.rules:
            try:
                findings.extend(rule.check(tree, ctx))
            except Exception:  # noqa: BLE001 - 单条规则失败不影响整体
                continue
```

注释写得很明白：一条坏规则不能拖垮整个审查。任何一条规则内部出 bug（比如遇到某个 AST 边界情况抛异常），其他 12 条照常工作——**这是「13 条规则独立开发、独立测试」能成立的前提**。

还有一处性能设计：所有规则共用一棵已解析的 AST（`ast.parse` 只调一次），每条规则自己 `ast.walk` 遍历——而不是每条规则重新解析一遍源码。对 62 个文件 × 13 条规则的规模，这个「单次解析多规则执行」的差别就是「几秒」和「几十秒」的差别。

## 3.2 13 条规则全览

`default_rules()` 返回默认规则集，覆盖质量 / bug / 性能 / 安全四个维度：

| ID | 规则 | 维度 | 严重级 | 置信度 | 检测机制（一句话） |
|---|---|---|---|---|---|
| CG001 | 可变默认参数 | bug | MAJOR | 1.0 | `FunctionDef` 的默认值是 List/Dict/Set 字面量、推导式或 `list()/dict()/set()` 调用 |
| CG002 | 裸 except | bug | MAJOR | 1.0 | `ExceptHandler.type is None` |
| CG003 | 异常被静默吞没 | bug | MAJOR | 1.0 | except 块体只有一条 `pass` |
| CG004 | `== None` 比较 | quality | MINOR | 1.0 | `Compare` 中 Eq / NotEq 的操作数是 None 常量 |
| CG005 | open() 未使用 with | bug | MINOR | **0.6** | open 调用沿父链上溯，不在 With / AsyncWith 内 |
| CG006 | 缺少 docstring | quality | MINOR / INFO | 0.9 | 公共符号 MINOR、私有符号 INFO；魔术方法与测试文件豁免 |
| CG007 | 循环内字符串拼接 | performance | MINOR | 0.8 | For / While 体内 `+=` 的右值是字符串字面量或 f-string |
| CG008 | 列表成员检查 | performance | INFO | 0.85 | `in` / `not in` 的右侧是 ≥3 元素的 List/Tuple 字面量 |
| CG009 | range(len(...)) 迭代 | best_practice | INFO | 0.95 | `for i in range(len(x))`；按是否用下标给不同建议 |
| CG010 | 过宽的 except Exception | quality | MINOR | 0.7 | 捕获类型恰为 `Exception` |
| CG011 | eval / exec 使用 | security | MAJOR | 1.0 | 调用名为 `eval` / `exec` 的 Name |
| CG012 | 硬编码敏感信息 | security | MAJOR | 0.75 | 变量名含密钥关键词 + 字符串值像真密钥（见 3.3） |
| CG013 | 命令注入风险 | security | MAJOR | 0.9~1.0 | `os.system` / `os.popen`，或 `subprocess` 带 `shell=True` |

这张表里藏着项目的一个核心概念：**置信度的语义**。

`confidence` 不是拍脑袋给的数字，它标明「这条发现是候选还是结论」：

- **1.0 / 0.95 / 0.9 档**：形态明确、几乎不可能是误报的（裸 except、`== None`、eval 调用）——可以直接进报告；
- **0.7~0.85 档**：形态可疑但需要结合上下文（循环内拼接在极小的循环里无所谓、过宽捕获在顶层兜底场景是合理的）——留给人工和 LLM 判断；
- **0.6 档**：CG005 独享——「open 不在 with 里」距离「资源泄漏」还隔着一句「调用方有没有手动 close」，**必须**经过复核。

这个分层不是装饰，它直接决定这些发现怎么被使用——第 05 篇会看到，候选发现进入任务简报时按严重级排序截断（最多 40 条），LLM 对每一条的选择是「重新提交（属实）」或「驳回（误报）」。

## 3.3 三条规则的设计细节

表格列完，挑三条展开——它们分别代表了三种不同的规则设计难题。

**CG001：检测「可变默认参数」，要考虑多少种写法？**

经典陷阱 `def f(x=[])` 的难点在覆盖面。规则的实现里有两组常量：

```python
    _MUTABLE_LITERAL = (ast.List, ast.Dict, ast.Set, ast.ListComp, ast.DictComp, ast.SetComp)
    _MUTABLE_FACTORY = ("list", "dict", "set")
```

字面量只是第一层——`x=[]`、`x={}`、`x=set()`（注意 `set()` 没有字面量写法）都要覆盖；推导式 `x=[i for i in range(3)]` 也是可变对象，也在检测范围内。默认参数分两组也要都看——普通参数在 `node.args.defaults`，仅关键字参数的默认值在 `node.args.kw_defaults`（可能含 None）：

```python
        defaults = list(node.args.defaults) + [
            d for d in node.args.kw_defaults if d is not None
        ]
```

修复建议的文案也是规则资产的一部分：

> 改用 None 作默认值，函数内部按需创建：`if x is None: x = []`

**CG005：一条规则的置信度为什么是 0.6？**

这条规则是全项目最能说明「规则与 LLM 分工」的例子。它的类注释把话说透了：

> 该规则只能发现"未在 with 内"的 open 调用；
> 调用方是否手动 close 需要语义确认，因此置信度设为 0.6，
> 由 Agent 的 LLM 环节复核后决定保留或丢弃。

检测本身很直接——遍历所有 `open` 调用，先建父节点映射，再沿父链上溯看有没有 With：

```python
def _build_parent_map(tree: ast.AST) -> dict[int, ast.AST]:
    """构建子节点 -> 父节点映射（用 id() 作为键，避免节点不可哈希问题）。"""
    parents: dict[int, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[id(child)] = parent
    return parents
```

注意 `id(child)` 这个键——AST 节点对象本身不可哈希（`ast.AST` 没实现 `__hash__` 的稳定语义），用对象身份做键是标准解法。上溯逻辑在 `_inside_with()` 里：从 open 节点出发一层层找 parent，碰到 With / AsyncWith 就返回 True。

然后是这条规则真正的设计点：**发现形态，但不下结论**。它报告的是「这里有一个不在 with 里的 open 调用」，建议文案里明确写了「（若已手动 close，请在复核时忽略本条）」——把判断权交给下一道工序。到了 Agent 循环里，这条候选会被两种方式处理：模型读了周边代码，确认真的漏了 close → 用 `submit_finding` 重新提交；确认有手动 close → 用 `dismiss_candidate` 显式驳回（第 05 篇展开这两个工具）。

**CG012：怎么让「硬编码密钥」不成为噪音机器？**

「找硬编码密钥」的朴素做法是「变量名里有 password 就报」——那会把 `password = "..."` 的占位符、示例、测试代码全部打进来。这条规则用了**双重条件**：名字要像，值也要像。

名字侧：

```python
    _HINTS = ("password", "passwd", "secret", "token", "api_key", "apikey", "access_key")
```

值侧有三道门：长度至少 6（太短的更像占位符）、不在占位符白名单、不以常见示例前缀开头：

```python
    _PLACEHOLDERS = {"password", "secret", "token", "changeme", "example", "placeholder", "xxx"}
```

```python
        if text.lower() in self._PLACEHOLDERS or text.lower().startswith(("your", "test", "<")):
            return []
```

也就是说 `API_KEY = "your-key-here"`、`token = "xxx"`、`password = "changeme"` 这些都会静默放过——**它们在教学文档和示例里出现得太频繁了，误报它们等于给工具刷负分**。置信度给 0.75 而不是 1.0 也是同理：名字和值都像的字符串仍可能是误报（比如本来就无害的公开测试 token），留一点复核余地。

顺便说一个不在表里的智慧：CG009 检测到 `for i in range(len(x))` 之后，会**看一眼循环体里有没有用下标**，再决定建议话术：

```python
        suggestion = (
            "需要索引和元素：改用 `for i, item in enumerate(x):`"
            if uses_index
            else "只需要元素：直接 `for item in x:` 迭代"
        )
```

同样一条检测，建议分两种场景——这是「建议必须可执行」这条守则（第 05 篇会看到它被写进系统提示词）在规则层的提前落地。

## 3.4 外部分析器：Ruff / Bandit / radon 的整合

自研规则只覆盖 13 种模式，生态里现成的轮子当然要用。三个外部分析器各管一段：

| 分析器 | 定位 | 调用方式 | 规则集 / 关键配置 |
|---|---|---|---|
| Ruff | 风格 / 命名 / 导入 / 潜在错误 | CLI 子进程，JSON 输出 | `select = "E,W,F,I,N"`（不选 D——docstring 交给自研 CG006，避免重复报告） |
| Bandit | 安全扫描 | CLI 子进程，JSON 输出 | 全量规则；报告中 B101/B108 在测试文件里豁免 |
| radon | 圈复杂度 / 可维护性 | **Python 库直接调用**（少一次子进程开销） | CC ≥ 10 报 MINOR、≥ 20 报 MAJOR |

三者都实现同一个 `Analyzer` 协议：

```python
class Analyzer(ABC):
    """确定性分析器协议。"""

    name: str = "analyzer"
    display: str = "分析器"
    supports_batch: bool = False  # True 时 pipeline 优先调用 run_batch（性能路径）

    @abstractmethod
    def is_available(self) -> bool:
        """工具是否可用（未安装时优雅跳过，不阻塞审查）。"""
```

`is_available()` 是一个重要的容错设计：**外部分析器没装，审查照跑**——`default_analyzers()` 的结果在 pipeline 里被过滤一次（`[a for a in default_analyzers() if a.is_available()]`），没装的就当不存在。用户不必为了体验 CodeSage 去装齐三个工具。

**`find_tool()`：一个不起眼但关键的工程细节。**

找外部工具（ruff.exe / bandit.exe）时，查找顺序是「当前解释器所在目录 → PATH」：

```python
    scripts_dir = Path(sys.executable).parent
    for name in (executable, f"{executable}.exe", f"{executable}.cmd"):
        candidate = scripts_dir / name
        if candidate.is_file():
            return str(candidate)
    return shutil.which(executable)
```

为什么第 1 步是「解释器所在目录」？注释里给了一个真实场景：

> 为什么需要第 1 步：不激活 venv 直接运行 codesage.exe 时，
> PATH 中不包含 venv/Scripts，Bandit 这类仅装在 venv 里的工具会找不到。

CodeSage 装在虚拟环境里，Bandit 作为依赖也装在同一个 venv 里。用户如果**没有激活 venv**、直接用 `codesage.exe` 的绝对路径运行，`PATH` 里根本没有 `venv/Scripts`——`shutil.which` 找不到 bandit。而从 `sys.executable`（当前跑的 Python）的目录出发找，就一定能找到同环境里的兄弟工具。优先用 venv 里的工具还有一个附带好处：保证用的是项目声明的那份依赖版本，不被系统全局装的老版本干扰。

**结果映射：把三个世界统一成 Finding。**

三家工具的输出格式、严重级词汇、置信度语义各不相同，映射层各写各的：

- **Ruff**：按规则码首字母分类，且 F 码里有一个「明确逻辑问题」子集会被提升到 MAJOR：

```python
_SEVERE_F_CODES = {
    "F821",  # undefined name
    "F811",  # redefinition of unused name
    "F823",  # local variable referenced before assignment
    "F502",  # expected list, got something else
    "F522",  # string formatting issues
    "F706",  # return outside function
    "F707",  # except after bare except
    "F901",  # raise NotImplemented
}
```

  其余 F 码是 MINOR、E/W 是 MINOR、N/I 是 INFO——默认置信度统一 0.9（Ruff 是确定性工具，但规则本身存在语境敏感的情况，留 0.1 余地）。

- **Bandit**：严重级和置信度双维度映射——`HIGH→MAJOR / MEDIUM→MINOR / LOW→INFO`，置信度 `HIGH→0.95 / MEDIUM→0.8 / LOW→0.6`。Bandit 自带的 confidence 正好可以和 Finding 的 confidence 对齐，这个映射几乎是白捡的。

- **radon**：以库形式调用，只把 CC ≥ 10 的*生产代码*函数变成发现（测试豁免，原因见 3.5）。

**批量扫描：从「逐文件调子进程」到「一次扫完目录」。**

三个分析器里有两个（Ruff、Bandit）是 CLI 子进程，而子进程是有启动成本的。`supports_batch = True` 的分析器在 pipeline 里走这条路径：

```python
    # 外部分析器：支持批量的走单次子进程调用（大仓库性能关键路径）
    # 传入 base_dir 让分析器直接扫描真实目录（避免临时目录的写删开销）
    for analyzer in analyzers:
        if getattr(analyzer, "supports_batch", False):
            batch = analyzer.run_batch(sources, base_dir=workspace)
            for findings in batch.values():
                det_findings.extend(findings)
        else:
            for rel, source in sources:
                det_findings.extend(analyzer.run(rel, source))
```

「传入 `base_dir` 直接扫描真实目录」这个参数背后是第 09 篇要讲的 44 倍性能故事的主角。这里先记住结论：**逐文件调 bandit 在 62 个文件的仓库上要 90 秒以上，因为每次调用要付约 1.5 秒的解释器启动成本；批量模式一次 `bandit -r` 扫完，只要 1.5 秒。**

## 3.5 误报控制：测试代码感知

这一篇讲一个「用自己审查自己」暴露出来的真实问题——它是整个项目里最有说服力的一段工程叙事。

**事故现场。** 项目开发到中段时，用 CodeSage 审查自己的 `tests/` 目录，结果令人尴尬：**208 条候选发现里绝大多数是噪音**——CG006「缺少 docstring」报在了每个测试函数上，Bandit B101（assert 使用）报在了每条断言上。测试代码的领域惯例（大量 assert、辅助函数不写 docstring、fixture 里硬编码临时路径）被当成了生产代码的问题，评分被扣到 0 分。这段事故记录被完整写进了回归测试文件的注释里：

```python
"""误报控制测试：测试代码感知（dogfooding 反馈的回归保护）。

背景：用 CodeSage 审查自己的 tests/ 目录时，发现 208 条候选里
绝大多数是噪音（CG006 缺 docstring 报在测试函数上、Bandit B101
报 assert 用法），评分被扣到 0 分。本文件锁定修复后的行为：
"""
```

**修复：一个基础设施 + 三处豁免。**

基础设施是 `analyzers/base.py` 里的 `is_test_file()`。它对「什么是测试代码」给出了一套覆盖 pytest 生态惯例的完整判断：

```python
def is_test_file(path: str) -> bool:
    """判断路径是否属于测试代码（误报控制的关键基础设施）。

    识别规则（pytest 生态的常见约定）：
    - 目录：路径中出现 test/ 或 tests/ 目录；
    - 文件名：test_*.py / *_test.py / conftest.py。

    为什么需要它：测试代码有其领域惯例——大量使用 assert、
    函数不写 docstring、fixture 中硬编码路径——这些在测试语境下
    是标准做法，报告它们属于典型误报（会淹没真实问题）。
    """
```

它认五种形态：`tests/` 或 `test/` 目录、`test_*.py`、`*_test.py`、`conftest.py`，并且兼容 Windows 的反斜杠路径（先做 `path.replace("\\", "/")` 归一化）。

测试文件里有个容易踩的坑，回归测试专门锁定了它：

```python
    assert not is_test_file("src/contest.py")   # 不误伤相近单词
    assert not is_test_file("latest_main.py")
```

`contest.py`、`latest_main.py` 名字里都有 "test" 字样——如果实现图省事用子串匹配，这两个文件就被误判了。实现用的是**文件名前缀/后缀 + 目录段精确匹配**，不会误伤。

在 `is_test_file` 之上，三处豁免各管一段：

| 位置 | 豁免内容 | 理由 |
|---|---|---|
| CG006 缺失 docstring | 测试文件整体豁免 | 测试辅助函数不写 docstring 是行业惯例 |
| Bandit B101 / B108 | `_TEST_FILE_SKIPS = {"B101", "B108"}`，且仅在测试文件中跳过 | B101 是 assert 用法（测试的标准断言手段）；B108 是固定临时路径（测试 fixture 常见做法） |
| radon 复杂度 | 测试文件整体豁免 | 测试函数因大量断言天然高复杂度，这是测试的合理形态 |

**「豁免不是放水」——这是整套设计里最重要的纪律。** 回归测试里有一条专门守住它：

```python
def test_bandit_still_reports_real_issues_in_test_files():
    """豁免仅限惯例用法：真实安全问题在测试文件中依然报告。"""
```

测试构造了一条 B602（`subprocess` 带 `shell=True`）的发现，文件在 `tests/` 下——断言它**照常报告**。豁免的恰恰是「测试语境下合理的做法」；真实的命令注入在测试文件里也是真实漏洞。

**这个故事的方法论意义**：

1. **dogfooding（自己吃自己的狗粮）是最诚实的测试**——静态分析器审查自己的测试目录，把「误报淹没真实问题」这个抽象风险变成了一次具体的 208 条噪音事故；
2. **修复方案分两层**：机制层（`is_test_file`）和策略层（三处各管一段的豁免），而不是在某个规则里打一个补丁；
3. **修复必须被测试锁定**：`tests/test_noise_control.py` 整整一个文件在守护这件事——正例（豁免生效）、反例（不误伤 contest.py）、以及边界（真实问题不放水）。

## 3.6 小结

- **三件套**：`RuleContext` 封装 Finding 构造、`Rule`/`NodeRule` 两种规则写法、`RuleEngine` 两个保护（语法错误报 CG000、单规则异常隔离）。单次解析多规则执行。
- **13 条规则**覆盖五个维度，**置信度分层**标明「候选 vs 结论」——CG005 的 0.6 是给 LLM 复核留的接口。
- **三个外部分析器**统一为 Analyzer 协议 + Finding：Ruff 有严重级提升子集、Bandit 双维度映射、radon 阈值分级；`find_tool` 优先在解释器所在目录找工具（不激活 venv 也能跑）。
- **误报控制**：`is_test_file` 基础设施 + 三处精确豁免 + 「豁免不是放水」的回归测试——这整套来自一次真实的 208 条噪音事故。

到这里，零 Token 的侦察工作结束。接下来是把候选发现和代码交给 Agent 的部分——项目的灵魂，第 04 篇开始拆 ReAct 循环。
