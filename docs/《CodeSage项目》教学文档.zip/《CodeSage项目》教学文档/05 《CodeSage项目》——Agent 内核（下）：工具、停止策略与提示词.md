# 《CodeSage项目》——Agent 内核（下）：工具、停止策略与提示词

## 5.1 工具注册表：让「声明」与「实现」不脱节

给模型用的每一个工具，都需要一份 JSON Schema：工具名、描述、参数列表、每个参数的类型和说明。手写这份 schema 是 bug 的温床——函数签名改了，schema 忘了改，模型就按过期的说明传参。

`agent/registry.py` 的解法是**反射生成**：schema 从函数签名和 docstring 自动产出。模块注释写明了这个判断：

> - Schema 从函数签名与类型注解反射生成，保证"实现与声明"不会脱节
>   （手写 schema 是常见 bug 来源）；
> - 参数描述从 docstring 的 Args 段解析，写好 docstring 即可获得好 schema；

`@tool` 装饰器本身极其克制——**只挂元数据，不产生任何副作用**：

```python
def tool(
    func: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
) -> Any:
    """装饰器：把函数标记为工具（只挂元数据，不产生全局副作用）。

    用法：
        @tool
        def read_file(path: str, start_line: int = 1) -> str:
            '''读取文件内容。

            Args:
                path: 文件路径
                start_line: 起始行号
            '''
            ...
    """
    def decorate(f: Callable[..., Any]) -> Callable[..., Any]:
        f._is_codesage_tool = True  # type: ignore[attr-defined]
        f._tool_name = name or f.__name__  # type: ignore[attr-defined]
        if description is not None:
            f._tool_description = description  # type: ignore[attr-defined]
        return f
```

「不产生全局副作用」的意思是：装饰器不会把函数塞进某个全局注册表（那种写法会让工具的注册时机依赖于 import 顺序，非常难调试）。注册动作是显式的——`ToolRegistry.register(func)` 被调用时才生成 schema：

```python
        properties: dict[str, Any] = {}
        required: list[str] = []
        signature = inspect.signature(func)
        for pname, param in signature.parameters.items():
            if pname in ("self", "cls"):
                continue
            schema = _annotation_to_schema(param.annotation)
            schema["description"] = param_docs.get(pname, pname)
            properties[pname] = schema
            if param.default is inspect.Parameter.empty:
                required.append(pname)
```

规则很朴素：有默认值的参数不是必填，没有默认值的是必填；类型注解走 `_annotation_to_schema()` 映射（`str→string`、`int→integer`、`list[str]→array`……）；参数描述从 docstring 的 Args 段解析出来——**所以「写好 docstring」和「模型能不能用对工具」是同一件事**，这个机制逼着工具作者把文档当接口写。

类型映射是刻意保守的：认不出的注解（联合类型、自定义类）一律回退为 `{"type": "string"}`。宁可让模型多传一个字符串，也不要生成一个模型看不懂的 schema。

**`execute()`：三道防线，永不抛异常。**

工具执行入口的设计目标是模块注释的那句话：

> execute() 永不抛出异常：工具错误被转成 "ERROR: ..." 文本回填给模型，
> 让模型自我纠正（这是 Agent 健壮性的关键设计）。

三道防线从头到尾：

```python
        tool_obj = self._tools.get(name)
        if tool_obj is None:
            return f"ERROR: 未知工具 '{name}'。可用工具：{', '.join(self.names())}"

        # 过滤多余参数（模型偶尔会带上 schema 外的键）
        valid = set(tool_obj.parameters.get("properties", {}))
        clean_args = {k: v for k, v in (arguments or {}).items() if k in valid}

        try:
            result = tool_obj.func(**clean_args)
        except TypeError as exc:
            missing = tool_obj.parameters.get("required", [])
            return f"ERROR: 参数不匹配（{exc}）。required 参数：{missing}"
        except Exception as exc:  # noqa: BLE001 - 有意兜底，转文本回填
            return f"ERROR: 工具 '{name}' 执行失败：{exc.__class__.__name__}: {exc}"

        text = self._stringify(result)
        if len(text) > max_result_chars:
            text = text[:max_result_chars] + f"\n...(结果已截断，共 {len(text)} 字符)"
        return text
```

1. **未知工具**：报错文本里带上全部可用工具名——模型看到清单后能自己改对；
2. **多余参数过滤**：模型偶尔会带上 schema 之外的键，静默剔除而不是报错（宽松接受）；参数缺失则回填「required 参数：[...]」——模型照着补；
3. **一切异常转文本**：包括 TypeError（参数不匹配）和任何工具内部异常。错误信息里带异常类名和消息——**模型读到 `ERROR: ...` 后会在下一轮调整策略，这就是「自我纠正」的机制**。如果这里让异常冒泡，整个审查当场结束，前面的发现全部作废；回填文本，最坏情况也只是模型换一个工具再试。

最后还有一道统一的输出截断（`max_result_chars` 默认 6000 字符）——这是 4.2 里循环调用时传入的那个上限，工具输出超出的部分被截断并**明确标注**「结果已截断，共 N 字符」，让模型知道信息不完整，从而自己决定是否换更精确的查询。

这套「错误也是信息」的设计有一个可以验证的投影——`tests/test_agent_loop.py` 里有三个专门的测试：未知工具、缺参数、工具内部异常，断言的是**同一件事**：循环最终 `status == "finished"`（不崩溃），且下一轮请求里有一条以 `ERROR` 开头的 tool 消息：

```python
def test_tool_exception_error_fed_back():
    ...
    result = loop.run(base_messages())
    assert result.status == "finished"  # 回填错误而非崩溃
```

## 5.2 七个工具：Agent 的「手」

工具集在 `tools/__init__.py` 里组装。模块注释先讲清楚组装方式：

```python
"""工具集：Agent 可调用的能力。

设计模式：工厂函数 + 依赖注入。
每个工具通过 make_xxx_tool(...) 创建，把工作区路径、分析器、知识库、
发现收集器等依赖闭包进去，工具函数本身保持"纯函数式"接口
（只接收模型给的参数），便于测试与复用。
"""
```

组装函数长这样：

```python
    registry = ToolRegistry()
    registry.register(make_read_file_tool(workspace, limit=read_limit))
    registry.register(make_search_code_tool(workspace))
    registry.register(make_list_symbols_tool(workspace))
    if analyzers:
        registry.register(make_run_analyzer_tool(analyzers, workspace))
    if knowledge_base is not None:
        registry.register(make_query_knowledge_tool(knowledge_base))
    registry.register(make_submit_finding_tool(findings_collector, workspace))
    if dismissed_collector is not None:
        registry.register(make_dismiss_candidate_tool(dismissed_collector))
    return registry
```

七个工具的全貌：

| 工具 | 作用 | 关键限制 | 对应「三级分工」的哪一级 |
|---|---|---|---|
| `read_file` | 读文件（带行号） | 单次 500 行上限；路径必须工作区内 | 为 LLM 提供原料 |
| `search_code` | 正则搜索 | 结果上限 100 条 | 定位手段（零成本） |
| `list_symbols` | 文件符号大纲（类/函数签名+行号） | 只列顶层与类方法 | 低成本了解结构 |
| `run_analyzer` | 按需触发 ruff / bandit / radon | 单次最多列 30 条问题 | **零 Token 的确定性通道** |
| `query_knowledge` | 检索最佳实践知识卡片 | top_k 夹在 1~5 | 权威依据（抑幻觉） |
| `submit_finding` | 提交一条结构化发现 | 枚举校验 + 同位置去重 | **复核结论的落地通道** |
| `dismiss_candidate` | 驳回一条候选发现 | 记录文件+行号+理由 | **误报过滤的落地通道** |

这张表里能看出工具的「供给侧」逻辑：

- **给模型眼睛**：`read_file`（细看）、`search_code`（搜索）、`list_symbols`（看结构）——三个不同粒度的信息获取，全部带硬上限；
- **给模型零成本的手**：`run_analyzer` 让模型可以随时说「对 order_processor.py 跑一遍 bandit」——确定性分析不再只是开场的固定动作，变成了**模型的按需工具**（而且不花 token）；
- **给模型嘴**：`submit_finding`（说「这里有真问题」）和 `dismiss_candidate`（说「这条候选是误报」）；
- **给模型依据**：`query_knowledge` 检索知识卡片，让「最佳实践建议」有出处可引，而不是模型自由发挥。

三个小工具的设计细节值得扫一眼：

**`read_file` 的行数上限是「从源头控制上下文增长」**（创建函数的 docstring 原话）。输出格式里有两个体贴的设计——文件头和续读提示：

```python
        out = [f"# {path}（共 {total} 行，当前显示 {start}-{end}）"]
        for i in range(start, end + 1):
            out.append(f"{i:>{width}} | {all_lines[i - 1]}")
        if end < total:
            out.append(f"...（还有 {total - end} 行未显示，可用 start_line={end + 1} 继续读取）")
```

「还有 N 行未显示，可用 start_line=... 继续读取」是写给模型看的分页协议——它知道怎么接着读。

**`search_code` 撞上上限时提示「请收窄正则」**：

```python
        suffix = f"\n...（已达上限 {max_results} 条，请收窄正则）" if truncated else ""
```

**`run_analyzer` 的描述是动态生成的**——注册时把可用分析器名字拼进工具描述（`description=f"对指定文件运行确定性分析器（零成本）。可用分析器：{available}"`），analyzers 列表里没有 bandit，模型就不知道有 bandit 可用。工具的 schema 描述会「说实话」。

## 5.3 两个关键工具：复核闭环的两端

七个工具里，`submit_finding` 和 `dismiss_candidate` 在架构上是一对——它们共同实现「**LLM 复核候选发现**」这个核心流程的闭环。值得展开。

**`submit_finding`：为什么用 function calling 提交，而不是让模型写文本？**

工具模块的注释直接回答了：

```python
"""submit_finding 工具：LLM 通过工具调用提交结构化发现。

这是本项目的一个关键设计：
- 让模型用 function calling 提交结构化数据，而不是输出自由文本再解析
  （自由文本解析是脆弱且不可靠的）；
- 参数校验失败时返回 ERROR 文本，模型会自动修正重试（自我纠正）；
- 同位置去重：保留置信度更高的版本。
"""
```

如果让模型在对话正文里写「问题描述 + 位置 + 建议」再让程序解析，就回到了文本解析 ReAct 的老路：格式一飘就解析失败。用工具调用，字段就是结构化的（file / line_start / line_end / category / severity / title / description / suggestion / confidence），校验不过就让模型重传。

校验逻辑本身就是自我纠正机制的应用——category 传了一个不在枚举里的值？

```python
        try:
            cat = Category(str(category).strip().lower())
        except ValueError:
            return f"ERROR: 非法 category '{category}'。可用值：{_CATEGORY_OPTIONS}"
```

错误文本里带着全部可用值，模型下一轮就改对了。

工具末尾的同位置去重和模型行为配合：

```python
        for idx, existing in enumerate(collector):
            if existing.dedup_key == finding.dedup_key:
                if finding.confidence > existing.confidence:
                    collector[idx] = finding
                    return f"已更新同位置发现（去重后共 {len(collector)} 条）：{finding.title}"
                return f"同位置已有更高置信度的发现，忽略本条（共 {len(collector)} 条）"
```

模型复核一条候选时的标准动作，是「读了代码后重新提交（附修复建议）」。如果它把同一条候选提交了两次，第二次会被去重——保留置信度更高的版本。注意工具返回的文案都带着「当前共 N 条」——**每次工具调用的返回值里都包含进度信息**，让模型对系统状态有持续的感知。

**`dismiss_candidate`：为什么「不提交」还不够？**

这是复核机制里最容易设计错的地方。模型的自然反应是「误报就不管它」——但候选发现是**规则引擎产出的**，它不在模型的发现列表里；模型不提交，它照样会进入最终报告。模块注释把这个漏洞说得很清楚：

```python
"""dismiss_candidate 工具：驳回候选发现（LLM 复核结论的落地通道）。

为什么需要它：
- AST 规则的候选发现里必然有误报（如"未使用 with"但实际已手动 close）；
- 如果模型只是"不重新提交"，原规则发现仍会进入报告——复核形同虚设；
- 因此提供显式驳回通道：被驳回的候选在合并阶段被过滤掉，
  驳回记录写入报告 metadata（可观测、可审计）。
"""
```

驳回动作记录在 `dismissed` 列表里，最终在 `pipeline.py` 的合并阶段生效：

```python
    if dismissed:

        def is_dismissed(finding: Finding) -> bool:
            if finding.source.value == "llm":
                return False
            for d in dismissed:
                if d["file"] != finding.file:
                    continue
                if abs(d["line"] - finding.line_start) <= 2:
                    return True
            return False

        det_findings = [f for f in det_findings if not is_dismissed(f)]

    return dedup_findings([*det_findings, *llm_findings])
```

三个细节：

1. **容差 ±2 行**：模型驳回时引用的行号来自候选清单，和规则原始的 `line_start` 可能差一两行——2 行容差保证「同一个位置」的判定稳定；
2. **只过滤确定性来源**：`finding.source.value == "llm"` 的直接跳过——驳回通道只对「规则/外部工具产出的候选」生效，模型自己的发现不在这里被误伤；
3. **驳回记录进 metadata**：`report.metadata["dismissed"]` 保留全部驳回（文件+行号+理由），报告里可审计——**「哪些候选被谁以什么理由驳掉了」是完全可查的**，而不是消失得无影无踪。

到这里，「复核闭环」的完整链路就串起来了：

```text
规则引擎产出候选（含误报）
      │ 按严重级排序，最多 40 条进任务简报
      ▼
模型逐条复核（read_file 读周边代码）
      │
      ├─ 属实 → submit_finding 重新提交（附修复建议、置信度）
      └─ 误报 → dismiss_candidate 显式驳回（附理由）
                        │
                        ▼
合并阶段：驳回的候选被过滤 → 去重 → 最终报告
```

## 5.4 停止策略：四次「刹车」

`agent/policies.py` 的模块注释先把四类停止条件列了出来：

```python
"""停止条件策略：Agent 循环的安全阀。

四类停止条件（对应规划文档）：
1. 模型主动结束（无 tool_calls）—— 正常完成；
2. 轮次上限 —— 防止无限循环；
3. Token 预算熔断（在 loop 中检查）；
4. 连续 N 轮无新增发现 —— 防止"原地打转"式低效循环。
"""
```

注意第 3 条的括号备注——**预算熔断在 loop 里检查，不在策略里**。策略类只负责它能看到的局部状态（轮次、进展），涉及全局预算的检查留在循环主流程。职责切分做得很细。

策略的完整实现只有十几行：

```python
    def check(self, state: AgentState) -> tuple[bool, str]:
        """返回 (是否停止, 原因)。"""
        if state.turn >= self.max_turns:
            return True, f"达到轮次上限（{self.max_turns} 轮）"

        history = state.findings_history
        patience = self.no_progress_patience
        if state.turn >= 3 and len(history) > patience:
            recent = history[-(patience + 1):]
            if len(set(recent)) == 1:
                return True, f"连续 {patience} 轮无新增发现（当前共 {recent[-1]} 条）"
        return False, ""
```

**无进展检测**的逻辑值得掰开看：

- `findings_history` 是每轮末记录一次「累计发现数」的列表，比如 `[2, 5, 5, 5]`；
- 检测条件是 `state.turn >= 3 and len(history) > patience`——至少跑满 3 轮才有资格判「无进展」，前期轮次本来就不该有发现；
- 取最近 `patience + 1` 个值（默认 patience=2，即最近 3 个），如果**它们全部相等**（`len(set(recent)) == 1`），说明最近 2 个完整轮次没有带来任何新发现——停止。

为什么是「连续 2 轮无新增」而不是「1 轮」？因为一轮没有发现可能只是这一轮在读一个干净的文件——模型在读代码、在验证候选，都是有效工作。连续两轮颗粒无收，才足够说明它在原地打转。这个阈值（`no_progress_patience: int = 2`）写在 `StopPolicy` 的字段默认值里，可以按需调整。

停止原因会带上具体数字：「连续 2 轮无新增发现（当前共 7 条）」——报告里出现这句话时，用户能一眼看懂「循环不是因为模型觉得自己干完了而停的，是策略让它停的」。

测试对这两条路径都有锁定：`test_max_turns_stops` 断言 `"轮次上限" in result.stop_reason`，`test_no_progress_stops` 用 `findings_counter=lambda: 0`（永远 0 条发现）构造出必停场景，断言 `"无新增发现" in result.stop_reason`。

## 5.5 提示词工程：系统提示就是质量资产

`agent/profiles.py` 里躺着这个项目最重要的「文字资产」——`BASE_SYSTEM_PROMPT`。模块注释说它「是审查质量的关键资产」，值得完整读一遍：

```text
你是 CodeSage，一名资深 Python 代码审查专家（Agent）。

工作方式：通过工具读取真实代码，基于证据给出结论。
每条问题必须通过 submit_finding 工具以结构化方式提交；
不要在对话正文中用自然语言罗列问题（对话正文只用于简短汇报进度）。

## 审查守则（必须遵守）

1. **先复核候选**：初始上下文给出了确定性分析的候选发现。
   逐一读取相关代码核实——属实则通过 submit_finding 重新提交（附修复方案），
   误报则直接忽略，不要提交。
2. **补充独立发现**：重点找规则抓不到的问题——逻辑错误、
   边界条件（空值/None/越界/空集合）、资源泄漏、异常路径、
   并发与共享状态污染。
3. **证据要求**：每条发现必须引用具体文件与行号，行号以 read_file
   返回的编号为准，禁止臆测未读过的代码。
4. **宁可漏报，不可误报**：证据不足时不提交——误报会直接降低
   工具的可信度。不确定的判断可以通过 reading 更多上下文来确认。
5. **建议必须可执行**：给出具体改法（改后代码或明确的操作），
   禁止"建议优化性能"这类空话。
6. **效率**：大文件分段读取（read_file 指定行号范围）；
   定位符号用 search_code / list_symbols，不要通读整库。
7. **尊重测试代码惯例**：`tests/` 目录与 `test_*.py` 文件中，
   大量使用 assert、辅助函数不写 docstring、fixture 硬编码临时路径
   等属于测试领域的标准做法——不要提交此类发现，只报告
   测试代码中真正的逻辑错误（如断言写反、mock 失效）。

## 审查维度清单（提交前自检覆盖情况）

- 代码质量：命名、风格一致性、注释与 docstring 完整性
- 潜在 Bug：逻辑错误、边界条件、异常处理、资源管理
- 性能：算法复杂度、循环内重复计算、数据结构选择
- 安全：注入（SQL / 命令）、反序列化、硬编码密钥、路径处理
- 最佳实践：Python 惯用法（Pythonic）、设计模式适用性（切忌过度设计）
```

七条守则逐一对应一个具体的失效模式，值得对照着看：

| 守则 | 防的是什么失效模式 | 对应的机制 |
|---|---|---|
| 1. 先复核候选 | 模型无视候选清单，自说自话 | submit_finding + dismiss_candidate 双通道 |
| 2. 补充独立发现 | 模型只做复核，不发挥语义推理能力 | 任务简报里「独立审查」段 |
| 3. 证据要求 | 行号幻觉（报没见过的问题） | read_file 提供带行号原文；Finding 强制要求 file:line |
| 4. 宁可漏报 | 误报淹没真实问题（3.5 的事故） | 复核机制 + 置信度字段 |
| 5. 建议可执行 | 「建议优化性能」式空话 | suggestion 字段强制填写 |
| 6. 效率 | 模型通读整库烧 token | read_file 分段 / search_code / list_symbols |
| 7. 测试惯例 | 测试代码噪音（208 条事故） | 与 `is_test_file` 豁免互为补充 |

其中第 3 条的「行号以 read_file 返回的编号为准」和第 7 条「只报告测试代码中真正的逻辑错误（如断言写反、mock 失效）」都是**从真实故障里提炼出来的补丁**，不是泛泛的措辞。

**Profile：同一个循环，三种聚焦。**

`profiles.py` 定义了三个角色，但它们的差异**只在 prompt 的聚焦说明**，代码执行路径完全一样：

| Profile | 标题 | focus 注入的内容 |
|---|---|---|
| `full` | 全面审查（五维度） | 空（不注入聚焦段） |
| `security` | 安全聚焦 | 注入类（SQL/命令/模板）、反序列化与 eval、硬编码凭据、路径穿越、SSRF、不安全随机数 |
| `performance` | 性能聚焦 | 算法复杂度、循环内重复计算/属性查找、数据结构选择、不必要物化与拷贝、I/O 模式 |

模块注释把取向说得很直白：

> Profile 只负责"聚焦维度"的差异化（full / security / performance），
> 避免为多角色而多角色——实现上是同一个循环 + 不同 Prompt。

这是一个很清醒的取舍：没有为「多角色」引入多 Agent 架构，而是把角色降维成 prompt 的一个参数。收益是复杂度归零，代价是不同角色的发现无法并行——对单目标 CLI 场景，这笔账划得来。

系统提示的最终组装在 `build_system_prompt()` 里，五段按固定顺序拼接：

```python
    parts: list[str] = [BASE_SYSTEM_PROMPT]

    profile = PROFILES.get(profile_name)
    if profile and profile.focus:
        parts.append(f"## 本次聚焦\n{profile.focus}")

    if workspace_summary:
        parts.append(f"## 项目背景\n{workspace_summary}")

    if lessons_block:
        parts.append(
            "## 历史经验（来自反馈错题本，供参考）\n"
            "以下模式曾被人工判定为误报或漏报，请在判断时注意：\n"
            f"{lessons_block}"
        )

    if budget_hint:
        parts.append(f"## 资源说明\n{budget_hint}")

    return "\n\n".join(parts)
```

五个插槽的信息来源各不相同：聚焦段来自 profile；项目背景来自项目级记忆（`memory/project.py` 扫 import 识别技术栈、扫描目录生成结构概览——零 token 的确定性分析）；历史经验来自自优化错题本（第 08 篇）；资源说明来自配置（「最多可执行 12 轮工具调用，请合理分配。」）。

**任务简报：token 控制的第一道闸门。**

系统的另一半输入是初始 user 消息，由 `agent/context.py` 的 `build_task_brief()` 生成。它的模块注释列出三条控制手段：

> Token 控制的第一道闸门：
> - 文件清单只给路径与行数（不给内容，让模型按需 read_file）；
> - 候选发现按严重级排序并限制条数（max_candidates）；
> - 分块策略提示（大文件怎么读）。

生成的简报长这样（f-string 模板，逐字摘自源码）：

```text
## 审查任务

目标：{target}（Python 文件 {len(files)} 个）
{scope_note}

## 文件清单（相对路径 | 行数）

{build_file_inventory(files)}

## 确定性分析候选发现（共 {len(candidates)} 条，需复核）

{build_candidates_block(candidates, max_candidates)}

## 建议的工作流程

1. 复核候选发现：读取相关代码确认属实性（属实→submit_finding 重新提交并附修复建议；误报→忽略）。
2. 独立审查文件：优先审查未被候选覆盖的文件与核心逻辑（工具、公共接口优先）。
3. 全部完成后，输出一段简短总结（不再调用工具）结束任务。
```

三个设计点：

- **文件清单只有「路径 | 行数」**——62 个文件的完整内容可能有几十万 token，但清单只有几百 token。模型拿着地图（哪里有什么、多大），按需派 `read_file` 去看——**这是「模型自主决定看什么」的入口设计**；候选按严重级排序截断：

```python
    order = {"critical": 0, "major": 1, "minor": 2, "info": 3}
    sorted_candidates = sorted(
        candidates,
        key=lambda f: (order[f.severity.value], f.file, f.line_start),
    )
    shown = sorted_candidates[:max_candidates]
```

  超过 40 条的截断会明确告知：「另有 N 条低优先级候选未列出」；

- **「建议的工作流程」是给模型的任务分解提示**——复核 → 独立审查 → 总结，三句话定义了整个 ReAct 循环的宏观剧本；最后一步「输出简短总结（不再调用工具）」直接对应循环的 `finished` 退出路径——**prompt 里写的结束方式和代码里的退出条件是对齐的**。

## 5.6 小结

- **注册表**：`@tool` 只挂元数据、`register()` 反射生成 schema（签名→类型、docstring→描述）；`execute()` 三道防线永不抛异常，错误转文本回填——自我纠正机制的地基。
- **七个工具**分三类：信息获取（read_file / search_code / list_symbols）、零成本分析（run_analyzer）、结论提交（submit_finding / dismiss_candidate）+ 权威依据（query_knowledge）。
- **复核闭环**：候选 → 模型读码复核 → 属实重提交 / 误报驳回；驳回带 ±2 行容差、只滤确定性来源、全程进 metadata 可审计。
- **停止策略**：轮次上限 + 连续 2 轮无新增发现（防原地打转）；预算检查留在 loop 里。
- **提示词**：七条守则每条对应一个真实失效模式；Profile 只改 prompt 不改代码路径；任务简报是 token 控制第一闸门（清单只给地图、候选限 40 条）。

Agent 内核讲完了。下面进入它背后那套「经济学」——上下文窗口是一种稀缺资源，三区记忆、双阈值、模型路由都是围绕它做的分配机制。
