# 《CodeSage项目》——确定性层（上）：从目录到代码块

## 2.1 扫描：三道筛子与一次剪枝

`codesage review <path>` 的第一步是搞清楚「审哪些文件」。这件事由 `ingest/filters.py` 的 `FileFilter` 和 `ingest/scanner.py` 的 `scan()` 配合完成。

`FileFilter.should_include()` 的模块注释写明了判断优先级：

> 判断优先级：排除目录 > 扩展名 > .gitignore > 大小（大小由 scanner 读文件后判断）。

逐个看：

**第一道：排除目录。** 默认列表在 `DEFAULT_EXCLUDES` 里——`.git`、`__pycache__`、`.venv`、`node_modules`、`.mypy_cache`、`.pytest_cache`、`.ruff_cache`、`build`、`dist`、`.eggs`、`.codesage`。注意最后那个 `.codesage`——项目自己的落盘目录（SQLite、评测产物）也不能审，否则会出现「审查结果把自己审查了一遍」的套娃。

**第二道：扩展名。** v1 只支持 Python：`path.suffix != ".py"` 直接跳过，跳过原因是「非 Python 文件（v1 仅支持 Python）」。这个诚实的分界是为了把一个月工期用在「做深」而不是「做广」——`analyzers/base.py` 的协议本身是语言无关的，多语言是 v2 的事。

**第三道：.gitignore 简易匹配。** 这里有一个值得尊重的工程诚实：实现用的是 `fnmatch` + 路径前缀的近似匹配，完整的 gitignore 语义（否定规则、`**` 递归通配）**不在 v1 范围内**——注释里就是这么写的。否定规则（`!` 开头的行）在读取时被直接跳过：

```python
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("!"):
                continue
            patterns.append(line.rstrip("/"))
```

**第四道（在 scanner 里）：大小。** `scan()` 读文件行数，超过 `max_file_lines`（默认 2000）的文件被跳过，跳过原因写明具体行数：`f"大文件预过滤（{lines} 行 > {file_filter.max_file_lines}）"`。单行文件也会被跳过（「空文件或单行文件」）。

`scan()` 还有一个小的性能设计：用 `os.walk(topdown=True)` 并在遍历时**原地修改 `dirnames`** 完成目录剪枝：

```python
    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        # 剪枝：原地修改 dirnames 阻止递归
        dirnames[:] = [d for d in dirnames if not file_filter.is_excluded_dir(d)]
```

`topdown=True` 时 `dirnames` 的修改会立即影响后续遍历——被剪掉的目录（比如 `.venv`）根本不会被走进去，而不是走进去后再逐个文件过滤。这是 `os.walk` 的标准性能用法，用在这里的意思很明确：**`.venv` 里可能有几千个文件，一个都不值得遍历。**

最后，`ScanResult` 记录的不只是「审哪些」，还有「跳过哪些、为什么」：

```python
@dataclass
class ScanResult:
    """扫描结果。"""

    files: list[Path] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)  # (相对路径, 原因)

    @property
    def total_candidates(self) -> int:
        return len(self.files) + len(self.skipped)
```

跳过原因是**透明可解释**的（模块 docstring 原话）——CLI 报告尾部会展示「已跳过 N 个文件，例如：……」，让用户知道工具到底看了什么、没看什么。审查工具最忌讳黑箱：如果它悄悄跳过了一个关键目录，用户又不知道，那结果就是不可信的。

## 2.2 切块：为什么按函数边界切，而不是滑动窗口

`ingest/chunker.py` 负责把源码切成「语义块」。它的模块注释先解释了为什么不用滑动窗口：

> 为什么不用滑动窗口：
> - 滑动窗口会把函数拦腰切断，模型看到的上下文语义是残的；
> - 按 AST 的函数/类边界切块，每块语义完整，且能带上符号名（供 prompt 引用）。

`chunk_source()` 的策略有四条（写在函数 docstring 里）：

```python
    """把源码切成语义块。

    策略：
    1. 解析失败（语法错误）→ 返回单块（交给上层决定是否报语法错误）；
    2. 文件不超过 max_chunk_lines → 返回单块（symbol=<module>）；
    3. 否则按顶层函数/类切块，间隙（import、模块级代码）归入 <module> 块；
    4. 超过 max_chunk_lines 的函数再按行窗口细分。
    """
```

两个细节值得看：

**装饰器的行号归属。** 切块时块起点不能直接用 `node.lineno`——对带装饰器的函数，那个行号指向 `def` 行，装饰器行会掉进上一个「间隙块」里，语义就被割裂了。所以代码专门把装饰器行纳入块范围：

```python
        start = node.lineno
        # 装饰器行也要包含在块内
        if getattr(node, "decorator_list", None):
            start = min(d.lineno for d in node.decorator_list)
```

**超长函数的二级切分。** 一个 800 行的巨型函数没法保证语义完整了，退化为带编号的行窗口：`f"{symbol}#part{idx}"`，`kind` 标记为 `window`。切块结果上带着 `symbol`（符号名），后续 prompt 里可以引用——「你在审查 `process_order#part2` 这个窗口」比「你在审查第 400-800 行」对模型友好得多。

**诚实标注**：`chunk_source` 当前只有测试在调用（`tests/test_ingest.py` 有正反例覆盖），**主链路暂未调用**。当前版本对大文件的处理策略是前一道筛子——超过 2000 行的文件直接预过滤跳过，配合 `read_file` 工具的分段读取（第 05 篇讲）由模型按需读取。切块器是为「细粒度分块 + 生成文件大纲」预留的设施，接口和测试都已就位。

## 2.3 增量审查：零依赖解析 git diff

`codesage review --changed` 是开发者日常最顺手的模式：**只审本次改动涉及的文件。** 这既省 token，又贴合真实工作流（提交前自查、CI 增量检查）。

实现放在 `ingest/git_diff.py`，核心是解析 `git diff` 的 hunk 头。模块注释交代了取舍：

> 实现方式：解析 `git diff HEAD -U0` 的 hunk 头（@@ -a,b +c,d @@），只取新增侧的行号范围。这是零依赖实现（不引入 GitPython）。

不引入 GitPython，用一个正则就够：

```python
HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@")
```

`-U0` 表示 diff 上下文的 0 行——审查场景只需要知道「新增了哪几行」。`+++ b/path/to/file.py` 这样的文件头用来切换当前文件，hunk 头用来累积行区间：

```python
        m = HUNK_RE.match(line)
        if m:
            start = int(m.group(1))
            length = int(m.group(2)) if m.group(2) else 1
            if length <= 0:
                continue
            result[current].append(HunkRange(start=start, end=start + length - 1))
```

按模块注释的说法，这样做「既省 Token 又符合开发者的真实工作流（对齐 CI / pre-commit 场景）」。

调用方在 `pipeline.py` 里，有一段很务实的降级逻辑：

```python
    # --changed：只保留 git 变更涉及的文件（非 git 仓库时回退全量，不报错）
    if options.changed_only:
        from codesage.ingest.git_diff import changed_line_ranges

        ranges = changed_line_ranges(workspace)
        if ranges:
            changed_files = {(workspace / rel).resolve() for rel in ranges}
            files = [f for f in files if f.resolve() in changed_files]
```

`changed_line_ranges()` 内部对所有失败路径（不是 git 仓库、git 命令超时、返回码非零）统统返回空 dict，pipeline 拿到空 dict 就保持全量文件——**「--changed 在一个非 git 目录里运行」不会报错，只是退化为全量**。工具在陌生环境里的行为可预期，比「精确报错」更重要。

**诚实标注**：`git_diff.py` 里还有一个 `expand_ranges()`（把行区间向外扩展 padding 行），有测试覆盖，但**主链路当前没有调用它**。也就是说，`--changed` 目前做到的是「文件级过滤」——被选中的文件仍然整文件审查；「行区间级裁剪」（只把变更行附近几行喂给模型）还没有接线。任务简报里有一句 `本次为**增量审查**：只关注 git 变更涉及的文件与行区间附近的代码。` 是在提示模型注意范围，但行区间本身尚未注入。这是 v1 的简化边界，也是 `expand_ranges` 为下一步准备好的轮子。

## 2.4 小结

- **扫描是四道筛子**：排除目录（含 `.codesage` 自己的产物）→ 扩展名 → .gitignore 简易匹配 → 大小预过滤；遍历时用 `os.walk` 原地剪枝，被排除目录根本不进。
- **跳过原因透明**：`ScanResult.skipped` 记录每条文件的跳过原因，报告尾部展示——审查工具不能是黑箱。
- **切块按函数边界**：装饰器行纳入块范围、超长函数二级细分；`chunk_source` 已实现并有测试，但主链路暂未调用（大文件当前走「预过滤 + read_file 分段读」）。
- **git diff 零依赖解析**：正则解析 hunk 头，取新增侧行区间；一切失败静默降级为全量，不报错。行区间级裁剪尚未接线。

扫出来的文件不能直接扔给模型——先让「零 Token 的侦察兵」过一遍。下一篇讲这个项目最扎实的资产：13 条自研 AST 规则和 3 个外部分析器。
